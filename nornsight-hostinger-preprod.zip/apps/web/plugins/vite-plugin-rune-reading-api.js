import { createRuneReading } from '../server/runeReadingService.js';
import { createFreeTirage, saveTirageEmail, unlockFullTirage } from '../server/tirageService.js';
import { getDrawingRepository } from '../server/data/drawingRepository.js';
import { getRequestContext, readJsonBody, sendJson } from '../server/http.js';

export default function runeReadingApiPlugin() {
  return {
    name: 'rune-reading-api',
    configureServer(server) {
      server.middlewares.use('/api/tirages/free', async (req, res, next) => {
        if (req.method !== 'POST') {
          return next();
        }

        try {
          const body = await readJsonBody(req);
          const context = getRequestContext(req);
          const result = await createFreeTirage({
            question: body.question,
            requestIp: context.ip
          });
          sendJson(res, 200, result);
        } catch (error) {
          sendJson(res, 500, { error: error?.message || 'Erreur inconnue.' });
        }
      });

      server.middlewares.use('/api/admin/tirages', async (req, res, next) => {
        if (req.method !== 'GET') {
          return next();
        }

        try {
          const url = new URL(req.url || '/', 'http://localhost');

          if (url.searchParams.get('preview_paid') !== '1') {
            sendJson(res, 403, { error: 'Forbidden.' });
            return;
          }

          const repository = await getDrawingRepository();
          const limit = Number(url.searchParams.get('limit') || '20');
          const tirages = await repository.listRecentDrawings(limit);

          sendJson(res, 200, { tirages });
        } catch (error) {
          sendJson(res, 500, { error: error?.message || 'Erreur inconnue.' });
        }
      });

      server.middlewares.use('/api/tirages/unlock', async (req, res, next) => {
        if (req.method !== 'POST') {
          return next();
        }

        try {
          const body = await readJsonBody(req);
          const context = getRequestContext(req);
          const result = await unlockFullTirage({
            ...body,
            requestIp: context.ip
          });

          sendJson(res, result.status === 'blocked' ? 429 : 200, result);
        } catch (error) {
          sendJson(res, 500, { error: error?.message || 'Erreur inconnue.' });
        }
      });

      server.middlewares.use('/api/tirages/save-email', async (req, res, next) => {
        if (req.method !== 'POST') {
          return next();
        }

        try {
          const body = await readJsonBody(req);
          const result = await saveTirageEmail({
            tirageId: body.tirageId,
            email: body.email
          });

          sendJson(res, 200, result);
        } catch (error) {
          sendJson(res, 500, { error: error?.message || 'Erreur inconnue.' });
        }
      });

      server.middlewares.use('/api/rune-reading', async (req, res, next) => {
        if (req.method !== 'POST') {
          return next();
        }

        try {
          const body = await readJsonBody(req);
          const reading = await createRuneReading(body);
          sendJson(res, 200, { reading });
        } catch (error) {
          const message =
            error?.message === 'OPENAI_API_KEY is missing.'
              ? 'La cle OpenAI n est pas configuree.'
              : error?.message || 'Erreur inconnue.';

          sendJson(res, 500, { error: message });
        }
      });
    }
  };
}

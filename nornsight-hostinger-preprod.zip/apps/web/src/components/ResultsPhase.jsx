import React from 'react';
import { motion } from 'framer-motion';
import { POSITION_LABELS } from '@/lib/runePositions.js';

const buildTeaserLead = (text) => {
  const trimmed = String(text || '').trim();
  if (!trimmed) {
    return '';
  }

  const sentence = trimmed.match(/[^.!?]+[.!?]?/);
  return (sentence?.[0] || trimmed).trim();
};

const splitFullReading = (text) => {
  if (!text) {
    return { paragraphs: [], closingQuestion: '' };
  }

  const trimmed = text.trim();
  const questionMatch = trimmed.match(/[^?]+\?\s*$/);
  const closingQuestion = questionMatch ? questionMatch[0].trim() : '';
  const body = closingQuestion ? trimmed.slice(0, -closingQuestion.length).trim() : trimmed;
  const sentences = body.match(/[^.!?]+[.!?]+/g) || (body ? [body] : []);

  if (sentences.length <= 2) {
    return {
      paragraphs: body ? [body] : [],
      closingQuestion
    };
  }

  const splitIndex = Math.ceil(sentences.length / 2);

  return {
    paragraphs: [
      sentences.slice(0, splitIndex).join(' ').trim(),
      sentences.slice(splitIndex).join(' ').trim()
    ].filter(Boolean),
    closingQuestion
  };
};

const ResultsPhase = ({
  runes,
  question,
  email,
  emailSaved,
  emailLimitNotice,
  freeReadingSummary,
  summaryStatus,
  teaserReading,
  teaserReadingStatus,
  teaserReadingError,
  adminPreviewEnabled,
  adminReadingUnlocked,
  isAdminTestEmail,
  fullReading,
  fullReadingStatus,
  fullReadingError,
  onEmailChange,
  onEmailSubmit,
  onDeepen,
  onNewDraw,
  onRetryTeaser,
  onRetryFullReading
}) => {
  const canShowUnlockBlock =
    teaserReadingStatus === 'success' || teaserReadingStatus === 'error' || emailSaved;
  const teaserLead = buildTeaserLead(teaserReading);
  const formattedFullReading = splitFullReading(fullReading);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen py-20 px-4"
    >
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="glass rounded-2xl p-6 mb-10"
        >
          <p className="text-sm text-muted-foreground mb-2">Par rapport à ce que tu traverses :</p>
          <p className="text-lg leading-relaxed">{question}</p>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-lg text-center text-muted-foreground mb-8 leading-relaxed max-w-2xl mx-auto"
        >
          Ce tirage ne répond pas à tout. Mais il met en lumière ce qui est déjà en train de se jouer dans ta situation.
        </motion.p>

        <div className="space-y-12 mb-12">
          {runes.map((rune, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 + index * 0.2 }}
              className="glass rounded-2xl p-8"
            >
              <div className="mb-4">
                <div className="text-sm font-medium text-accent mb-3 tracking-wide uppercase">
                  {rune.positionLabel || POSITION_LABELS[index]}
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-6xl text-accent">{rune.symbole}</div>
                  <div className="font-['Cinzel'] text-3xl font-semibold">{rune.nom}</div>
                </div>
              </div>

              <div className="mt-6">
                <p className="text-muted-foreground leading-relaxed text-lg">
                  {rune.interpretation}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.85 }}
          className="glass rounded-2xl p-8 mb-10 text-center"
        >
          <p className="text-xl md:text-2xl leading-relaxed text-muted-foreground max-w-3xl mx-auto">
            {freeReadingSummary}
          </p>

          {summaryStatus === 'loading' && (
            <p className="text-sm text-muted-foreground/70 mt-4 animate-pulse">
              La lecture se précise encore.
            </p>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.93 }}
          className="glass rounded-2xl p-8 mb-10 text-center"
        >
          <p className="text-lg md:text-xl leading-relaxed text-muted-foreground max-w-3xl mx-auto">
            Ce tirage met déjà en lumière quelque chose d&apos;important.
            <br />
            Mais ce qui se joue réellement va plus loin que ce que tu vois ici.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="glass rounded-2xl p-8 mb-10"
        >
          <div className="mb-6">
            <p className="text-sm font-medium text-accent tracking-wide uppercase mb-2">
              Aller plus loin
            </p>
            <h3 className="font-['Cinzel'] text-3xl md:text-4xl font-semibold" style={{ letterSpacing: '-0.02em' }}>
              Aller plus loin dans la lecture
            </h3>
          </div>

          {teaserReadingStatus === 'loading' && (
            <p className="text-lg text-muted-foreground leading-relaxed animate-pulse">
              Le tirage est en train de se resserrer autour de ce qu&apos;il touche vraiment.
            </p>
          )}

          {teaserReading && (
            <div className="space-y-5">
              <p className="text-lg leading-relaxed text-muted-foreground">
                {teaserLead}
              </p>
            </div>
          )}

          {teaserReadingStatus === 'error' && (
            <div className="rounded-xl border border-white/6 bg-black/10 px-5 py-5 space-y-4">
              <p className="text-lg text-muted-foreground leading-relaxed">
                Le teaser n&apos;a pas pu se charger pour l&apos;instant.
              </p>
              {teaserReadingError && <p className="text-sm text-muted-foreground/80">{teaserReadingError}</p>}
              <button
                onClick={onRetryTeaser}
                className="glass-strong px-6 py-3 rounded-xl text-base font-medium transition-all duration-300 active:scale-[0.98]"
              >
                Réessayer
              </button>
            </div>
          )}

          {canShowUnlockBlock && (
            <div className="space-y-6 mt-8">
              <div className="glass-strong rounded-2xl p-6">
                <h4 className="font-['Cinzel'] text-2xl font-semibold mb-3" style={{ letterSpacing: '-0.02em' }}>
                  Recevoir ce tirage par email
                </h4>

                <p className="text-lg text-muted-foreground leading-relaxed mb-6 max-w-2xl">
                  Pour pouvoir le relire à tête reposée et recevoir ensuite les prochaines guidances.
                </p>

                <form onSubmit={onEmailSubmit} className="space-y-4">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => onEmailChange(e.target.value)}
                    required
                    placeholder="ton@email.com"
                    className="w-full glass rounded-xl px-6 py-4 text-lg focus:outline-none focus:ring-2 focus:ring-accent transition-all duration-300 placeholder:text-muted-foreground/50"
                  />

                  <button
                    type="submit"
                    disabled={!email.trim() || fullReadingStatus === 'loading' || (emailSaved && Boolean(fullReading))}
                    className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-none"
                  >
                    {emailSaved ? 'Tirage enregistré' : 'Recevoir ce tirage'}
                  </button>
                </form>

                {emailLimitNotice && (
                  <div className="mt-5 rounded-xl border border-amber-300/10 bg-amber-300/5 px-4 py-4">
                    <p className="text-sm md:text-base leading-relaxed text-muted-foreground/95">
                      {emailLimitNotice}
                    </p>
                  </div>
                )}
              </div>

              <div className="glass-strong rounded-2xl p-6">
                <h4 className="font-['Cinzel'] text-2xl font-semibold mb-3" style={{ letterSpacing: '-0.02em' }}>
                  Aller plus loin dans la lecture — 5,90 €
                </h4>

                <p className="text-lg text-muted-foreground leading-relaxed mb-6 max-w-2xl">
                  Une lecture plus précise de ce qui maintient la situation et de ce qui peut vraiment la faire évoluer.
                </p>

                <button
                  onClick={onDeepen}
                  type="button"
                  className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98]"
                >
                  {adminReadingUnlocked
                    ? 'Voir la lecture approfondie'
                    : adminPreviewEnabled
                      ? 'Prévisualiser la lecture approfondie'
                      : 'Commander la lecture approfondie'}
                </button>

                {(adminPreviewEnabled || adminReadingUnlocked) && (
                  <p className="text-sm text-accent/90 leading-relaxed mt-4">
                    Accès admin actif. La lecture approfondie peut être affichée sans paiement.
                  </p>
                )}

                {isAdminTestEmail && !adminReadingUnlocked && fullReadingStatus !== 'loading' && (
                  <p className="text-sm text-muted-foreground/80 leading-relaxed mt-4">
                    Après validation de l&apos;email admin, la lecture approfondie s&apos;affiche directement ici.
                  </p>
                )}
              </div>
            </div>
          )}

          {adminReadingUnlocked && emailSaved && fullReadingStatus === 'loading' && (
            <p className="text-lg text-muted-foreground leading-relaxed mt-8 animate-pulse">
              La lecture complète est en train de se déployer...
            </p>
          )}

          {adminReadingUnlocked && emailSaved && fullReading && (
            <div className="mt-8 space-y-6">
              <div className="border-t border-white/5 pt-8">
                <div className="max-w-3xl space-y-5">
                  {formattedFullReading.paragraphs.map((paragraph, index) => (
                    <p
                      key={index}
                      className="text-lg leading-[1.95] text-muted-foreground"
                    >
                      {paragraph}
                    </p>
                  ))}

                  {formattedFullReading.closingQuestion && (
                    <p className="text-lg leading-[1.9] text-foreground/90 pt-2">
                      {formattedFullReading.closingQuestion}
                    </p>
                  )}
                </div>
              </div>

              <button
                onClick={onDeepen}
                className="glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98]"
              >
                Approfondir en séance
              </button>
            </div>
          )}

          {adminReadingUnlocked && fullReadingStatus === 'error' && emailSaved && (
            <div className="mt-8 rounded-xl border border-white/6 bg-black/10 px-5 py-5 space-y-4">
              <p className="text-lg text-muted-foreground leading-relaxed">
                La lecture complète n&apos;a pas pu être chargée pour l&apos;instant.
              </p>
              {fullReadingError && <p className="text-sm text-muted-foreground/80">{fullReadingError}</p>}
              <button
                onClick={onRetryFullReading}
                className="glass-strong px-6 py-3 rounded-xl text-base font-medium transition-all duration-300 active:scale-[0.98]"
              >
                Réessayer
              </button>
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.15 }}
          className="flex justify-center"
        >
          <button
            onClick={onNewDraw}
            className="glass-strong px-8 py-4 rounded-xl text-lg font-medium hover:bg-muted/50 transition-all duration-300 active:scale-[0.98]"
          >
            Faire un nouveau tirage
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default ResultsPhase;

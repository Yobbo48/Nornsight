import React from 'react';
import { motion } from 'framer-motion';

const splitFullReading = (text) => {
  if (!text) {
    return { paragraphs: [], closingQuestion: '' };
  }

  const trimmed = text.trim();
  const questionMatch = trimmed.match(/[^?]+\?\s*$/);
  const closingQuestion = questionMatch ? questionMatch[0].trim() : '';
  const body = closingQuestion ? trimmed.slice(0, -closingQuestion.length).trim() : trimmed;
  const sentences = body.match(/[^.!?]+[.!?]+/g) || (body ? [body] : []);

  if (sentences.length <= 2) {
    return {
      paragraphs: body ? [body] : [],
      closingQuestion
    };
  }

  const splitIndex = Math.ceil(sentences.length / 2);

  return {
    paragraphs: [
      sentences.slice(0, splitIndex).join(' ').trim(),
      sentences.slice(splitIndex).join(' ').trim()
    ].filter(Boolean),
    closingQuestion
  };
};

const VALUE_POINTS = [
  'Ce qui tient réellement la situation en place',
  'Ce qui fragilise ou freine la dynamique',
  'Ce qui peut vraiment évoluer'
];

const DeepReadingPhase = ({
  question,
  adminPreviewEnabled,
  adminReadingUnlocked,
  isAdminTestEmail,
  fullReading,
  fullReadingStatus,
  fullReadingError,
  onBack,
  onUnlock,
  onRetry
}) => {
  const formattedFullReading = splitFullReading(fullReading);
  const canAccessReading = adminPreviewEnabled || adminReadingUnlocked || isAdminTestEmail;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen py-20 px-4"
    >
      <div className="max-w-3xl mx-auto space-y-8">
        <button
          type="button"
          onClick={onBack}
          className="text-sm uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-colors"
        >
          Revenir au tirage
        </button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="glass rounded-2xl p-8 md:p-10"
        >
          <div className="space-y-6">
            <div className="space-y-3">
              <p className="text-sm font-medium text-accent tracking-wide uppercase">Lecture approfondie</p>
              <h1 className="font-['Cinzel'] text-3xl md:text-4xl font-semibold" style={{ letterSpacing: '-0.02em' }}>
                Une lecture plus précise de ce que le tirage met réellement en jeu.
              </h1>
            </div>

            <div className="rounded-xl border border-white/5 bg-black/10 px-5 py-4">
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-2">Ta question</p>
              <p className="text-base md:text-lg leading-relaxed text-foreground/90">{question}</p>
            </div>

            <div className="space-y-4">
              {VALUE_POINTS.map((point) => (
                <div key={point} className="flex gap-4 items-start">
                  <div className="mt-2 h-1.5 w-1.5 rounded-full bg-accent/80" />
                  <p className="text-base md:text-lg text-muted-foreground leading-relaxed">{point}</p>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-white/5 space-y-4">
              <p className="font-['Cinzel'] text-3xl font-semibold">5,90 €</p>
              <button
                type="button"
                onClick={onUnlock}
                disabled={fullReadingStatus === 'loading' || !canAccessReading}
                className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {canAccessReading
                  ? fullReadingStatus === 'loading'
                    ? 'Prévisualisation en cours'
                    : adminReadingUnlocked
                      ? 'Afficher la lecture complète'
                      : 'Débloquer la lecture complète'
                  : 'Débloquer la lecture complète'}
              </button>

              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                Lecture disponible immédiatement après paiement, et envoyée par email.
              </p>

              {canAccessReading && (
                <p className="text-sm text-accent/90 leading-relaxed">
                  Accès admin actif. Le bouton affiche directement la lecture sans paiement.
                </p>
              )}

              {!canAccessReading && (
                <p className="text-sm text-muted-foreground/80 leading-relaxed">
                  Cette étape est prête à accueillir le paiement. Le branchement Stripe viendra juste après.
                </p>
              )}
            </div>
          </div>
        </motion.div>

        {canAccessReading && fullReadingStatus === 'loading' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="glass rounded-2xl p-8"
          >
            <p className="text-lg text-muted-foreground leading-relaxed animate-pulse">
              La lecture approfondie se met en place...
            </p>
          </motion.div>
        )}

        {canAccessReading && fullReading && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="glass rounded-2xl p-8 md:p-10"
          >
            <div className="space-y-5">
              {formattedFullReading.paragraphs.map((paragraph, index) => (
                <p key={index} className="text-lg leading-[1.95] text-muted-foreground">
                  {paragraph}
                </p>
              ))}

              {formattedFullReading.closingQuestion && (
                <p className="text-lg leading-[1.9] text-foreground/90 pt-2">
                  {formattedFullReading.closingQuestion}
                </p>
              )}
            </div>
          </motion.div>
        )}

        {canAccessReading && fullReadingStatus === 'error' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="glass rounded-2xl p-8 space-y-4 border border-white/6"
          >
            <p className="text-lg text-muted-foreground leading-relaxed">
              La lecture approfondie n&apos;a pas pu être générée pour l&apos;instant.
            </p>
            {fullReadingError && <p className="text-sm text-muted-foreground/80">{fullReadingError}</p>}
            <button
              type="button"
              onClick={onRetry}
              className="glass-strong px-6 py-3 rounded-xl text-base font-medium transition-all duration-300 active:scale-[0.98]"
            >
              Réessayer
            </button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default DeepReadingPhase;


import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import runeData from '@/data/runeData.js';
import AdminHistoryPanel from '@/components/AdminHistoryPanel.jsx';
import ResultsPhase from '@/components/ResultsPhase.jsx';
import DeepReadingPhase from '@/components/DeepReadingPhase.jsx';
import { ADMIN_PREVIEW_EMAIL, isAdminPreviewEnabled } from '@/lib/adminPreview.js';
import { createFreeTirage, fetchAdminDrawings, fetchRuneReading, saveTirageEmail, unlockFullReading } from '@/lib/runeReadingApi.js';
import { createFreeReadingSummary } from '@/lib/runeReadingPrompt.js';
import {
  POSITION_KEYS,
  POSITION_LABELS,
  getPositionSourceKey,
  buildPositionInterpretation
} from '@/lib/runePositions.js';
const CURRENT_STATE_KEY = 'nornsight_current_state';
const DEEPENING_KEY = 'nornsight_deepening_interest';
const LEADS_KEY = 'nornsight_leads';
const AI_STATUS = {
  idle: 'idle',
  loading: 'loading',
  success: 'success',
  error: 'error'
};

const normalizeEmail = (value) => value.trim().toLowerCase();
const QUESTION_FORM_ID = 'question-form';

const HOW_IT_WORKS = [
  {
    step: '1',
    title: 'Tu poses ta question',
    text: 'Une situation précise ou un ressenti encore flou.'
  },
  {
    step: '2',
    title: 'Trois runes sont tirées',
    text: 'Le tirage fait apparaître ce qui est déjà là.'
  },
  {
    step: '3',
    title: 'Tu obtiens une lecture',
    text: 'Une lecture claire, puis un approfondissement si besoin.'
  }
];

const READING_PILLARS = [
  'Faire apparaître ce qui travaille déjà la situation',
  'Montrer où elle se tend ou se fragilise',
  'Ouvrir sur ce qui peut réellement évoluer'
];

const scrollToQuestionForm = () => {
  const element = document.getElementById(QUESTION_FORM_ID);
  if (!element) {
    return;
  }

  element.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const textarea = element.querySelector('textarea');
  if (textarea) {
    window.setTimeout(() => textarea.focus(), 350);
  }
};

const HomePage = () => {
  const [phase, setPhase] = useState('question');
  const [question, setQuestion] = useState('');
  const [drawnRunes, setDrawnRunes] = useState([]);
  const [revealedCards, setRevealedCards] = useState([false, false, false]);
  const [loadingText, setLoadingText] = useState('Connexion aux runes...');
  const [email, setEmail] = useState('');
  const [emailSaved, setEmailSaved] = useState(false);
  const [activeDrawingId, setActiveDrawingId] = useState('');
  const [emailLimitNotice, setEmailLimitNotice] = useState('');
  const [deepenRequested, setDeepenRequested] = useState(false);
  const [freeReadingSummary, setFreeReadingSummary] = useState('');
  const [summaryStatus, setSummaryStatus] = useState(AI_STATUS.idle);
  const [teaserReading, setTeaserReading] = useState('');
  const [teaserReadingStatus, setTeaserReadingStatus] = useState(AI_STATUS.idle);
  const [teaserReadingError, setTeaserReadingError] = useState('');
  const [fullReading, setFullReading] = useState('');
  const [fullReadingStatus, setFullReadingStatus] = useState(AI_STATUS.idle);
  const [fullReadingError, setFullReadingError] = useState('');
  const [adminPreviewEnabled, setAdminPreviewEnabled] = useState(false);
  const [adminReadingUnlocked, setAdminReadingUnlocked] = useState(false);
  const [adminDrawings, setAdminDrawings] = useState([]);
  const [adminHistoryStatus, setAdminHistoryStatus] = useState(AI_STATUS.idle);
  const [adminHistoryError, setAdminHistoryError] = useState('');
  const isAdminTestEmail = normalizeEmail(email) === ADMIN_PREVIEW_EMAIL;
  const revealTimersRef = useRef([]);

  useEffect(() => {
    setAdminPreviewEnabled(isAdminPreviewEnabled());
  }, []);

  useEffect(() => () => {
    revealTimersRef.current.forEach((timer) => window.clearTimeout(timer));
    revealTimersRef.current = [];
  }, []);

  useEffect(() => {
    if (!adminPreviewEnabled) {
      return;
    }

    const controller = new AbortController();

    const loadAdminHistory = async () => {
      setAdminHistoryStatus(AI_STATUS.loading);
      setAdminHistoryError('');

      try {
        const payload = await fetchAdminDrawings({ limit: 20, signal: controller.signal });
        setAdminDrawings(Array.isArray(payload.tirages) ? payload.tirages : []);
        setAdminHistoryStatus(AI_STATUS.success);
      } catch (error) {
        if (error?.name === 'AbortError') {
          return;
        }

        setAdminDrawings([]);
        setAdminHistoryStatus(AI_STATUS.error);
        setAdminHistoryError(error?.message || 'Impossible de charger l’historique admin.');
      }
    };

    loadAdminHistory();

    return () => controller.abort();
  }, [adminPreviewEnabled, phase]);

  useEffect(() => {
    const savedState = localStorage.getItem(CURRENT_STATE_KEY);
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        if (parsed.phase === 'results') {
          localStorage.removeItem(CURRENT_STATE_KEY);
          return;
        }

        if (parsed.phase && parsed.question && parsed.drawnRunes) {
          setPhase(parsed.phase);
          setQuestion(parsed.question);
          setDrawnRunes(parsed.drawnRunes);
          setEmail(parsed.email || '');
          setEmailSaved(Boolean(parsed.emailSaved));
          setActiveDrawingId(parsed.activeDrawingId || '');
          setEmailLimitNotice(parsed.emailLimitNotice || '');
          setDeepenRequested(Boolean(parsed.deepenRequested));
          setFreeReadingSummary(parsed.freeReadingSummary || '');
          setSummaryStatus(parsed.summaryStatus || AI_STATUS.idle);
          setTeaserReading(parsed.teaserReading || '');
          setTeaserReadingStatus(parsed.teaserReadingStatus || AI_STATUS.idle);
          setTeaserReadingError(parsed.teaserReadingError || '');
          setFullReading(parsed.fullReading || '');
          setFullReadingStatus(parsed.fullReadingStatus || AI_STATUS.idle);
          setFullReadingError(parsed.fullReadingError || '');
          setAdminReadingUnlocked(Boolean(parsed.adminReadingUnlocked));
        }
      } catch (error) {
        console.error('Error loading saved state:', error);
      }
    }
  }, []);

  const saveCurrentState = (newPhase, newQuestion, newRunes, nextState = {}) => {
    const state = {
      phase: newPhase,
      question: newQuestion,
      drawnRunes: newRunes,
      email,
      emailSaved,
      activeDrawingId,
      emailLimitNotice,
      deepenRequested,
      freeReadingSummary,
      summaryStatus,
      teaserReading,
      teaserReadingStatus,
      teaserReadingError,
      fullReading,
      fullReadingStatus,
      fullReadingError,
      adminReadingUnlocked,
      ...nextState
    };
    localStorage.setItem(CURRENT_STATE_KEY, JSON.stringify(state));
  };

  const persistResultsState = (overrides = {}) => {
    saveCurrentState('results', question, drawnRunes, {
      email,
      emailSaved,
      activeDrawingId,
      emailLimitNotice,
      deepenRequested,
      freeReadingSummary,
      summaryStatus,
      teaserReading,
      teaserReadingStatus,
      teaserReadingError,
      fullReading,
      fullReadingStatus,
      fullReadingError,
      adminReadingUnlocked,
      ...overrides
    });
  };

  const drawRunes = () => {
    const shuffled = [...runeData].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, 3);

    return selected.map((rune, index) => {
      const positionKey = POSITION_KEYS[index];
      const sourceKey = getPositionSourceKey(positionKey, index);
      const positionInterpretations = rune.interpretations[positionKey] || [];
      const randomIndex = Math.floor(Math.random() * positionInterpretations.length);

      return {
        symbole: rune.symbole,
        nom: rune.nom,
        positionKey,
        positionSourceKey: sourceKey,
        positionLabel: POSITION_LABELS[index],
        interpretation: buildPositionInterpretation(
          positionKey,
          sourceKey,
          rune.referential.positions[sourceKey].summary
        ),
        detailedInterpretation: positionInterpretations[randomIndex],
        essenceSummary: rune.essence.summary,
        essenceKeywords: rune.essence.keywords,
        referential: rune.referential
      };
    });
  };

  const buildInterpretationSnapshot = (runes) =>
    runes.map((rune) => ({
      position: rune.positionLabel,
      rune: rune.nom,
      symbole: rune.symbole,
      texte: rune.interpretation,
      detail: rune.detailedInterpretation,
      essence: rune.essenceSummary,
      keywords: rune.essenceKeywords
    }));

  const buildSavedInterpretation = () => ({
    runes: buildInterpretationSnapshot(drawnRunes),
    freeReadingSummary,
    teaserReading,
    fullReading
  });

  const requestReading = async (mode, questionValue, runeSet) => {
    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 20000);

    try {
      const result = await fetchRuneReading({
        question: questionValue,
        runes: runeSet,
        mode,
        signal: controller.signal
      });

      return result.reading;
    } finally {
      window.clearTimeout(timeoutId);
    }
  };

  const startRevealSequence = ({ trimmedQuestion, tirageId, runes, summary, teaser }) => {
    setDrawnRunes(runes);
    setActiveDrawingId(tirageId);
    setFreeReadingSummary(summary);
    setSummaryStatus(AI_STATUS.idle);
    setTeaserReading(teaser);
    setTeaserReadingStatus(teaser ? AI_STATUS.success : AI_STATUS.idle);
    setTeaserReadingError('');
    setLoadingText('Les runes se dévoilent...');

    saveCurrentState('revealing', trimmedQuestion, runes, {
      email: '',
      emailSaved: false,
      activeDrawingId: tirageId,
      emailLimitNotice: '',
      deepenRequested: false,
      freeReadingSummary: summary,
      summaryStatus: AI_STATUS.idle,
      teaserReading: teaser,
      teaserReadingStatus: teaser ? AI_STATUS.success : AI_STATUS.idle,
      teaserReadingError: '',
      fullReading: '',
      fullReadingStatus: AI_STATUS.idle,
      fullReadingError: '',
      adminReadingUnlocked: false
    });

    revealTimersRef.current.push(window.setTimeout(() => {
      setRevealedCards([true, false, false]);
    }, 450));

    revealTimersRef.current.push(window.setTimeout(() => {
      setRevealedCards([true, true, false]);
    }, 1250));

    revealTimersRef.current.push(window.setTimeout(() => {
      setRevealedCards([true, true, true]);
    }, 2050));

    revealTimersRef.current.push(window.setTimeout(() => {
      setPhase('results');
      saveCurrentState('results', trimmedQuestion, runes, {
        email: '',
        emailSaved: false,
        activeDrawingId: tirageId,
        emailLimitNotice: '',
        deepenRequested: false,
        freeReadingSummary: summary,
        summaryStatus: AI_STATUS.idle,
        teaserReading: teaser,
        teaserReadingStatus: teaser ? AI_STATUS.success : AI_STATUS.idle,
        teaserReadingError: '',
        fullReading: '',
        fullReadingStatus: AI_STATUS.idle,
        fullReadingError: '',
        adminReadingUnlocked: false
      });
      window.scrollTo({ top: 0, behavior: 'smooth' });
      revealTimersRef.current = [];
    }, 3050));
  };

  const generateTeaserReading = async (questionValue, runeSet) => {
    setTeaserReadingStatus(AI_STATUS.loading);
    setTeaserReadingError('');
    persistResultsState({
      teaserReading: '',
      teaserReadingStatus: AI_STATUS.loading,
      teaserReadingError: ''
    });

    try {
      const reading = await requestReading('teaser', questionValue, runeSet);

      setTeaserReading(reading);
      setTeaserReadingStatus(AI_STATUS.success);
      setTeaserReadingError('');
      saveCurrentState('results', questionValue, runeSet, {
        teaserReading: reading,
        teaserReadingStatus: AI_STATUS.success,
        teaserReadingError: ''
      });
    } catch (error) {
      const message =
        error?.name === 'AbortError'
          ? 'Le teaser a pris trop de temps à arriver.'
          : error?.message || 'Impossible de générer le teaser.';

      setTeaserReading('');
      setTeaserReadingStatus(AI_STATUS.error);
      setTeaserReadingError(message);
      saveCurrentState('results', questionValue, runeSet, {
        teaserReading: '',
        teaserReadingStatus: AI_STATUS.error,
        teaserReadingError: message
      });
    }
  };

  const generateSummaryReading = async (questionValue, runeSet) => {
    setSummaryStatus(AI_STATUS.loading);
    persistResultsState({
      summaryStatus: AI_STATUS.loading
    });

    try {
      const reading = await requestReading('summary', questionValue, runeSet);

      setFreeReadingSummary(reading);
      setSummaryStatus(AI_STATUS.success);
      saveCurrentState('results', questionValue, runeSet, {
        freeReadingSummary: reading,
        summaryStatus: AI_STATUS.success
      });
    } catch (error) {
      console.error('Error generating summary reading:', error);
      setSummaryStatus(AI_STATUS.error);
      saveCurrentState('results', questionValue, runeSet, {
        summaryStatus: AI_STATUS.error
      });
    }
  };

  useEffect(() => {
    if (
      phase === 'results' &&
      question &&
      drawnRunes.length === 3 &&
      summaryStatus === AI_STATUS.idle &&
      freeReadingSummary
    ) {
      generateSummaryReading(question, drawnRunes);
    }
  }, [phase, question, drawnRunes, summaryStatus, freeReadingSummary]);

  useEffect(() => {
    if (
      phase === 'results' &&
      question &&
      drawnRunes.length === 3 &&
      teaserReadingStatus === AI_STATUS.idle &&
      !teaserReading
    ) {
      generateTeaserReading(question, drawnRunes);
    }
  }, [phase, question, drawnRunes, teaserReadingStatus, teaserReading]);

  const handleQuestionSubmit = async (e) => {
    e.preventDefault();
    if (question.trim()) {
      revealTimersRef.current.forEach((timer) => window.clearTimeout(timer));
      revealTimersRef.current = [];

      const trimmedQuestion = question.trim();
      setQuestion(trimmedQuestion);
      setDrawnRunes([]);
      setRevealedCards([false, false, false]);
      setLoadingText('Le tirage se met en place...');
      setPhase('revealing');
      setEmail('');
      setEmailSaved(false);
      setActiveDrawingId('');
      setEmailLimitNotice('');
      setDeepenRequested(false);
      setFreeReadingSummary('');
      setSummaryStatus(AI_STATUS.idle);
      setTeaserReading('');
      setTeaserReadingStatus(AI_STATUS.idle);
      setTeaserReadingError('');
      setFullReading('');
      setFullReadingStatus(AI_STATUS.idle);
      setFullReadingError('');
      setAdminReadingUnlocked(false);
      saveCurrentState('revealing', trimmedQuestion, [], {
        email: '',
        emailSaved: false,
        activeDrawingId: '',
        emailLimitNotice: '',
        deepenRequested: false,
        freeReadingSummary: '',
        summaryStatus: AI_STATUS.idle,
        teaserReading: '',
        teaserReadingStatus: AI_STATUS.idle,
        teaserReadingError: '',
        fullReading: '',
        fullReadingStatus: AI_STATUS.idle,
        fullReadingError: '',
        adminReadingUnlocked: false
      });
      window.scrollTo({ top: 0, behavior: 'smooth' });

      try {
        const payload = await createFreeTirage({ question: trimmedQuestion });
        startRevealSequence({
          trimmedQuestion,
          tirageId: payload.tirageId || '',
          runes: payload.runes || [],
          summary: payload.summary || '',
          teaser: payload.teaser || ''
        });
      } catch (error) {
        console.error('Error creating free tirage on server:', error);
        const runes = drawRunes();
        startRevealSequence({
          trimmedQuestion,
          tirageId: '',
          runes,
          summary: createFreeReadingSummary({ runes, question: trimmedQuestion }),
          teaser: ''
        });
      }
    }
  };

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    if (email.trim()) {
      const normalizedEmail = normalizeEmail(email);

      if (activeDrawingId) {
        try {
          await saveTirageEmail({
            tirageId: activeDrawingId,
            email: normalizedEmail
          });
        } catch (error) {
          console.error('Error saving lead on server:', error);
        }
      }

      try {
        const existingLeads = JSON.parse(localStorage.getItem(LEADS_KEY) || '[]');
        existingLeads.push({
          id: `lead_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          email: normalizedEmail,
          question,
          tirageId: activeDrawingId || null,
          runes: buildInterpretationSnapshot(drawnRunes),
          savedAt: new Date().toISOString()
        });
        localStorage.setItem(LEADS_KEY, JSON.stringify(existingLeads));
      } catch (error) {
        console.error('Error saving lead locally:', error);
      }

      setEmail(normalizedEmail);
      setEmailSaved(true);
      setEmailLimitNotice('');
      persistResultsState({
        email: normalizedEmail,
        emailSaved: true,
        emailLimitNotice: ''
      });

      if (normalizedEmail === ADMIN_PREVIEW_EMAIL) {
        setFullReadingStatus(AI_STATUS.loading);
        setFullReadingError('');
        persistResultsState({
          email: normalizedEmail,
          emailSaved: true,
          fullReading: '',
          fullReadingStatus: AI_STATUS.loading,
          fullReadingError: '',
          adminReadingUnlocked: false
        });

        try {
          const payload = await unlockFullReading({
            tirageId: activeDrawingId,
            email: normalizedEmail,
            question,
            runes: drawnRunes,
            freeReadingSummary,
            teaserReading
          });

          setActiveDrawingId(payload.tirageId || activeDrawingId);
          setFullReading(payload.reading || '');
          setFullReadingStatus(AI_STATUS.success);
          setFullReadingError('');
          setAdminReadingUnlocked(Boolean(payload.reading));
          persistResultsState({
            activeDrawingId: payload.tirageId || activeDrawingId,
            email: normalizedEmail,
            emailSaved: true,
            fullReading: payload.reading || '',
            fullReadingStatus: AI_STATUS.success,
            fullReadingError: '',
            adminReadingUnlocked: Boolean(payload.reading)
          });
        } catch (error) {
          console.error('Error unlocking admin reading from server:', error);

          try {
            const reading = await requestReading('full', question, drawnRunes);

            setFullReading(reading);
            setFullReadingStatus(AI_STATUS.success);
            setFullReadingError('');
            setAdminReadingUnlocked(true);
            persistResultsState({
              email: normalizedEmail,
              emailSaved: true,
              fullReading: reading,
              fullReadingStatus: AI_STATUS.success,
              fullReadingError: '',
              adminReadingUnlocked: true
            });
          } catch (fallbackError) {
            const message =
              fallbackError?.name === 'AbortError'
                ? 'La lecture approfondie a pris trop de temps à arriver.'
                : fallbackError?.message || 'Impossible de générer la lecture approfondie.';

            setFullReading('');
            setFullReadingStatus(AI_STATUS.error);
            setFullReadingError(message);
            setAdminReadingUnlocked(false);
            persistResultsState({
              email: normalizedEmail,
              emailSaved: true,
              fullReading: '',
              fullReadingStatus: AI_STATUS.error,
              fullReadingError: message,
              adminReadingUnlocked: false
            });
          }
        }
      }
    }
  };

  const handleDeepen = () => {
    const payload = {
      question,
      runes: drawnRunes,
      interpretation: buildSavedInterpretation(),
      requestedAt: new Date().toISOString()
    };

    try {
      localStorage.setItem(DEEPENING_KEY, JSON.stringify(payload));
    } catch (error) {
      console.error('Error saving deepening intent:', error);
    }

    setDeepenRequested(true);
    saveCurrentState('deep-reading', question, drawnRunes, {
      email,
      emailSaved,
      activeDrawingId,
      emailLimitNotice,
      deepenRequested: true
    });
    setPhase('deep-reading');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const generatePaidReadingPreview = async () => {
    if ((!adminPreviewEnabled && !isAdminTestEmail && !adminReadingUnlocked) || !question || drawnRunes.length !== 3) {
      return;
    }

    setFullReadingStatus(AI_STATUS.loading);
    setFullReadingError('');
    saveCurrentState('deep-reading', question, drawnRunes, {
      email,
      emailSaved,
      activeDrawingId,
      emailLimitNotice,
      deepenRequested: true,
      fullReading: '',
      fullReadingStatus: AI_STATUS.loading,
      fullReadingError: ''
    });

    try {
      const reading = await requestReading('full', question, drawnRunes);
      setFullReading(reading);
      setFullReadingStatus(AI_STATUS.success);
      setFullReadingError('');
      setAdminReadingUnlocked(true);
      saveCurrentState('deep-reading', question, drawnRunes, {
        email,
        emailSaved,
        activeDrawingId,
        emailLimitNotice,
        deepenRequested: true,
        fullReading: reading,
        fullReadingStatus: AI_STATUS.success,
        fullReadingError: '',
        adminReadingUnlocked: true
      });
    } catch (error) {
      const message =
        error?.name === 'AbortError'
          ? 'La lecture approfondie a pris trop de temps à arriver.'
          : error?.message || 'Impossible de générer la lecture approfondie.';

      setFullReading('');
      setFullReadingStatus(AI_STATUS.error);
      setFullReadingError(message);
      saveCurrentState('deep-reading', question, drawnRunes, {
        email,
        emailSaved,
        activeDrawingId,
        emailLimitNotice,
        deepenRequested: true,
        fullReading: '',
        fullReadingStatus: AI_STATUS.error,
        fullReadingError: message,
        adminReadingUnlocked: false
      });
    }
  };

  const handleBackToResults = () => {
    setPhase('results');
    persistResultsState({
      deepenRequested: true
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNewDraw = () => {
    setPhase('question');
    setQuestion('');
    setDrawnRunes([]);
    setRevealedCards([false, false, false]);
    setLoadingText('Connexion aux runes...');
    setEmail('');
    setEmailSaved(false);
    setActiveDrawingId('');
    setEmailLimitNotice('');
    setDeepenRequested(false);
    setFreeReadingSummary('');
    setSummaryStatus(AI_STATUS.idle);
    setTeaserReading('');
    setTeaserReadingStatus(AI_STATUS.idle);
    setTeaserReadingError('');
    setFullReading('');
    setFullReadingStatus(AI_STATUS.idle);
    setFullReadingError('');
    setAdminReadingUnlocked(false);
    localStorage.removeItem(CURRENT_STATE_KEY);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRetryTeaser = () => {
    generateTeaserReading(question, drawnRunes);
  };

  const handleRetryFullReading = () => {
    generatePaidReadingPreview();
  };

  return (
    <>
      <Helmet>
        <title>Nornsight - Un regard clair sur ce que tu traverses</title>
        <meta name="description" content="Tirage de runes pour éclairer ta situation présente" />
      </Helmet>

      <div className="min-h-screen bg-[#0d0c0a] text-[#ede8df] relative overflow-hidden font-['Outfit']">
        <div className="pointer-events-none absolute inset-0 opacity-40 [background-image:radial-gradient(circle_at_top,rgba(184,146,74,0.08),transparent_36%),radial-gradient(circle_at_80%_18%,rgba(138,109,59,0.08),transparent_20%)]" />
        <div className="pointer-events-none absolute inset-0 opacity-[0.06] [background-image:linear-gradient(rgba(232,226,214,0.12)_1px,transparent_1px),linear-gradient(90deg,rgba(232,226,214,0.12)_1px,transparent_1px)] [background-size:120px_120px]" />
        <div className="relative z-10">
          <AnimatePresence mode="wait">
            {phase === 'question' && (
              <motion.div
                key="question"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
                className="px-4 py-14 md:py-20"
              >
                <div className="max-w-5xl mx-auto w-full space-y-24 md:space-y-28">
                  <motion.section
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    className="relative overflow-hidden pt-6 md:pt-10"
                  >
                    <div className="absolute inset-x-0 top-0 h-[26rem] opacity-25 bg-[radial-gradient(circle_at_top,rgba(184,146,74,0.16),transparent_55%)] pointer-events-none" />
                    <div className="absolute right-10 top-20 h-40 w-40 rounded-full bg-[#b8924a]/5 blur-3xl pointer-events-none" />
                    <div className="relative max-w-3xl mx-auto text-center space-y-8 md:space-y-10">
                      <div className="text-[0.68rem] uppercase tracking-[0.35em] text-[#b8924a]">
                        Tirage de runes guidé
                      </div>

                      <div className="space-y-6">
                        <div className="flex items-center justify-center gap-4 text-[#8a6d3b]/80">
                          <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#8a6d3b]/40" />
                          <span className="text-sm">ᚱ</span>
                          <div className="h-px w-16 bg-gradient-to-l from-transparent to-[#8a6d3b]/40" />
                        </div>
                        <h1
                          className="font-['Cormorant_Garamond'] text-6xl md:text-7xl lg:text-[5.6rem] font-normal leading-none"
                          style={{ letterSpacing: '-0.02em' }}
                        >
                          Nornsight
                        </h1>
                        <h2
                          className="font-['Cormorant_Garamond'] text-[2.4rem] md:text-[3.15rem] lg:text-[4.1rem] font-light leading-[1.03] max-w-2xl mx-auto"
                          style={{ letterSpacing: '-0.02em' }}
                        >
                          Un tirage pour éclairer ce que tu traverses vraiment.
                        </h2>
                        <p className="text-[0.98rem] md:text-[1.05rem] text-[#a09880] leading-relaxed max-w-md mx-auto tracking-[0.02em]">
                          Une lecture sobre et claire. Pour voir plus juste.
                        </p>
                      </div>

                      <div className="flex flex-col items-center gap-5 pt-2">
                        <button
                          type="button"
                          onClick={scrollToQuestionForm}
                          className="inline-flex items-center gap-3 border border-[#8a6d3b]/60 px-7 py-3.5 text-[0.72rem] uppercase tracking-[0.24em] text-[#d4aa6a] transition-all duration-300 hover:border-[#d4aa6a] hover:text-[#e8cfa0] hover:bg-[#8a6d3b]/8 active:scale-[0.98]"
                        >
                          Faire un tirage
                        </button>
                        <div className="text-sm md:text-[0.95rem] text-[#a09880] leading-relaxed text-center max-w-[18rem]">
                          3 runes. Une lecture. Puis la suite si tu veux.
                        </div>
                      </div>
                    </div>
                  </motion.section>

                  <motion.section
                    id={QUESTION_FORM_ID}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className="max-w-2xl mx-auto"
                  >
                    <div className="rounded-[1.35rem] border border-[#c8bfaa]/10 bg-[#141310]/75 p-6 md:p-7 backdrop-blur-sm shadow-[0_18px_60px_rgba(0,0,0,0.24)]">
                      <div className="space-y-3 mb-5">
                        <p className="text-[0.65rem] font-medium tracking-[0.32em] uppercase text-[#b8924a]">
                          Commencer
                        </p>
                        <p className="text-[0.95rem] md:text-base text-[#a09880] leading-relaxed max-w-md">
                          Écris simplement ce qui te traverse.
                        </p>
                      </div>

                      <motion.form
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.35 }}
                        onSubmit={handleQuestionSubmit}
                        className="space-y-4"
                      >
                        <textarea
                          value={question}
                          onChange={(e) => setQuestion(e.target.value)}
                          required
                          placeholder="Écris ce qui te traverse..."
                          className="w-full h-48 rounded-[1.1rem] border border-[#c8bfaa]/10 bg-[#0e0d0b]/65 p-5 text-[1.02rem] resize-none focus:outline-none focus:ring-1 focus:ring-[#b8924a]/60 transition-all duration-300 placeholder:text-[#7a7468] text-[#ede8df]"
                        />

                        <button
                          type="submit"
                          disabled={!question.trim()}
                          className="w-full border border-[#8a6d3b]/60 px-7 py-3.5 rounded-[1rem] text-[0.72rem] font-medium uppercase tracking-[0.24em] text-[#d4aa6a] transition-all duration-300 hover:border-[#d4aa6a] hover:text-[#e8cfa0] hover:bg-[#8a6d3b]/8 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Lancer le tirage
                        </button>
                      </motion.form>
                    </div>
                  </motion.section>

                  <motion.section
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.25 }}
                    className="max-w-4xl mx-auto"
                  >
                    <div className="mx-auto mb-12 flex max-w-[220px] items-center gap-5 px-4">
                      <div className="h-px flex-1 bg-[#c8bfaa]/12" />
                      <div className="text-[0.6rem] uppercase tracking-[0.35em] text-[#5a5448]">Parcours</div>
                      <div className="h-px flex-1 bg-[#c8bfaa]/12" />
                    </div>
                    <div className="grid gap-0 border border-[#c8bfaa]/10 bg-[#141310]/35 md:grid-cols-3">
                      {HOW_IT_WORKS.map((item, index) => (
                        <div
                          key={item.step}
                          className={`min-h-[220px] px-7 py-8 md:px-8 md:py-9 ${index < HOW_IT_WORKS.length - 1 ? 'border-b border-[#c8bfaa]/10 md:border-b-0 md:border-r' : ''} border-[#c8bfaa]/10`}
                        >
                          <div className="font-['Cormorant_Garamond'] text-5xl font-light text-[#c8bfaa]/18 mb-5">{item.step}</div>
                          <h3 className="font-['Outfit'] text-[0.74rem] uppercase tracking-[0.2em] text-[#b8924a] mb-4">
                            {item.title}
                          </h3>
                          <p className="text-[0.95rem] md:text-base text-[#a09880] leading-relaxed max-w-[16rem]">
                            {item.text}
                          </p>
                        </div>
                      ))}
                    </div>
                  </motion.section>

                  <motion.section
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.3 }}
                    className="space-y-20 max-w-4xl mx-auto"
                  >
                    <div className="max-w-2xl relative space-y-8">
                      <div className="pointer-events-none absolute -left-8 top-2 h-16 w-16 rounded-full border border-[#b8924a]/10" />
                      <div className="text-[0.6rem] uppercase tracking-[0.35em] text-[#5a5448] mb-4">Lecture</div>
                      <h3 className="font-['Cormorant_Garamond'] text-3xl md:text-[2.9rem] font-light max-w-lg leading-[1.08]" style={{ letterSpacing: '-0.02em' }}>
                        Une lecture qui tient sa ligne
                      </h3>
                      <div className="space-y-5">
                        {READING_PILLARS.map((item) => (
                          <div key={item} className="flex gap-4 items-start">
                            <div className="mt-2 h-1.5 w-1.5 rounded-full bg-[#b8924a]/90" />
                            <p className="text-[0.98rem] md:text-base text-[#a09880] leading-relaxed max-w-md">{item}</p>
                          </div>
                        ))}
                      </div>
                      <div className="border-t border-b border-[#c8bfaa]/10 px-2 py-8 md:px-6">
                        <p className="text-[1rem] md:text-[1.02rem] leading-loose text-[#a09880] max-w-xl">
                          Le tirage avance avec méthode : un passé, un présent, un futur.
                          <br />
                          La lecture ne cherche pas l’effet. Elle cherche la justesse.
                        </p>
                      </div>
                    </div>
                  </motion.section>

                  <motion.section
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.35 }}
                    className="grid gap-16 md:grid-cols-[1fr_1fr] max-w-4xl mx-auto items-start"
                  >
                    <div className="max-w-sm relative">
                      <div className="pointer-events-none absolute -left-6 -top-5 h-10 w-24 border-t border-l border-[#c8bfaa]/10" />
                      <p className="text-[0.6rem] font-medium tracking-[0.35em] uppercase text-[#5a5448] mb-3">
                        À propos
                      </p>
                      <h3 className="font-['Cormorant_Garamond'] text-3xl md:text-[2.8rem] font-light mb-4" style={{ letterSpacing: '-0.02em' }}>
                        Kevin Legros
                      </h3>
                      <p className="text-[0.98rem] md:text-base text-[#a09880] leading-relaxed max-w-sm">
                        Auteur, praticien des runes et énergéticien depuis 2015.
                        <br />
                        Une présence sobre, guidée par la clarté et l’expérience.
                      </p>
                    </div>

                    <div className="max-w-md md:ml-auto md:text-right">
                      <p className="text-[0.6rem] font-medium tracking-[0.35em] uppercase text-[#5a5448] mb-3">
                        Fondement
                      </p>
                      <h3 className="font-['Cormorant_Garamond'] text-3xl md:text-[2.6rem] font-light mb-4" style={{ letterSpacing: '-0.02em' }}>
                        Fondement
                      </h3>
                      <p className="text-[0.98rem] md:text-base text-[#a09880] leading-relaxed max-w-md md:ml-auto">
                        Nornsight s’appuie sur un travail réel autour des runes : des années de pratique, des tirages menés en séance, et une écriture construite pour faire émerger ce qui se joue avec netteté.
                      </p>
                    </div>
                  </motion.section>

                  <motion.section
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.4 }}
                    className="text-center py-6"
                  >
                    <div className="max-w-2xl mx-auto space-y-6 relative">
                      <h3 className="font-['Cormorant_Garamond'] text-3xl md:text-[3rem] font-light leading-[1.12]" style={{ letterSpacing: '-0.02em' }}>
                        Le tirage commence là où ta question devient claire.
                      </h3>
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={scrollToQuestionForm}
                          className="inline-flex items-center gap-3 border border-[#8a6d3b]/60 px-7 py-3.5 text-[0.72rem] uppercase tracking-[0.24em] text-[#d4aa6a] transition-all duration-300 hover:border-[#d4aa6a] hover:text-[#e8cfa0] hover:bg-[#8a6d3b]/8 active:scale-[0.98]"
                        >
                          Faire un tirage
                        </button>
                      </div>
                    </div>
                  </motion.section>

                  <motion.footer
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.45 }}
                    className="text-center text-[0.78rem] tracking-[0.14em] text-[#5a5448] pb-4"
                  >
                    Une création de Kevin Legros — L’énergie des Runes
                  </motion.footer>
                </div>
              </motion.div>
            )}

            {phase === 'revealing' && (
              <motion.div
                key={`revealing-${activeDrawingId || question}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
                className="min-h-screen flex flex-col items-center justify-center px-4 py-20"
              >
                <motion.p
                  key={loadingText}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="text-2xl md:text-3xl text-center text-muted-foreground mb-16"
                >
                  {loadingText}
                </motion.p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl w-full">
                  {Array.from({ length: 3 }).map((_, index) => {
                    const rune = drawnRunes[index];

                    return (
                    <motion.div
                      key={`${activeDrawingId || question}-${index}-${rune?.nom || 'pending'}-${rune?.symbole || 'back'}`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.2 }}
                      className="relative h-96"
                      style={{ perspective: '1000px' }}
                    >
                      <div
                        className="relative w-full h-full transition-all duration-700"
                        style={{
                          transformStyle: 'preserve-3d',
                          transform: revealedCards[index] ? 'rotateY(180deg)' : 'rotateY(0deg)'
                        }}
                      >
                        <div
                          className="absolute inset-0 glass-strong rounded-2xl flex items-center justify-center"
                          style={{ backfaceVisibility: 'hidden' }}
                        >
                          <div className="text-6xl opacity-20">ᚱᚢᚾᛖ</div>
                        </div>

                        <div
                          className={`absolute inset-0 glass-strong rounded-2xl flex flex-col items-center justify-center p-6 transition-all duration-700 ${
                            revealedCards[index] && rune ? 'glow-primary' : ''
                          }`}
                          style={{
                            backfaceVisibility: 'hidden',
                            transform: 'rotateY(180deg)'
                          }}
                        >
                          <div className="text-8xl mb-4 text-accent">{rune?.symbole || 'ᚱ'}</div>
                          <div className="font-['Cinzel'] text-2xl font-semibold">{rune?.nom || 'Rune'}</div>
                        </div>
                      </div>
                    </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {phase === 'results' && (
              <ResultsPhase
                key="results"
                runes={drawnRunes}
                question={question}
                email={email}
                emailSaved={emailSaved}
                emailLimitNotice={emailLimitNotice}
                freeReadingSummary={freeReadingSummary}
                summaryStatus={summaryStatus}
                teaserReading={teaserReading}
                teaserReadingStatus={teaserReadingStatus}
                teaserReadingError={teaserReadingError}
                adminPreviewEnabled={adminPreviewEnabled}
                adminReadingUnlocked={adminReadingUnlocked}
                isAdminTestEmail={isAdminTestEmail}
                fullReading={fullReading}
                fullReadingStatus={fullReadingStatus}
                fullReadingError={fullReadingError}
                onEmailChange={setEmail}
                onEmailSubmit={handleEmailSubmit}
                onDeepen={handleDeepen}
                onNewDraw={handleNewDraw}
                onRetryTeaser={handleRetryTeaser}
                onRetryFullReading={handleRetryFullReading}
              />
            )}

            {phase === 'deep-reading' && (
              <DeepReadingPhase
                key="deep-reading"
                question={question}
              adminPreviewEnabled={adminPreviewEnabled}
              adminReadingUnlocked={adminReadingUnlocked}
              isAdminTestEmail={isAdminTestEmail}
              fullReading={fullReading}
              fullReadingStatus={fullReadingStatus}
              fullReadingError={fullReadingError}
                onBack={handleBackToResults}
                onUnlock={generatePaidReadingPreview}
                onRetry={generatePaidReadingPreview}
              />
            )}
          </AnimatePresence>
        </div>
      </div>

      {adminPreviewEnabled && (phase === 'question' || phase === 'results' || phase === 'deep-reading') && (
        <div className="relative z-10 px-4 pb-16">
          <div className="max-w-5xl mx-auto">
            <AdminHistoryPanel
              drawings={adminDrawings}
              status={adminHistoryStatus}
              error={adminHistoryError}
            />
          </div>
        </div>
      )}

      {phase === 'results' && deepenRequested && (
        <div className="fixed bottom-6 left-1/2 z-20 w-[calc(100%-2rem)] max-w-xl -translate-x-1/2 glass-strong rounded-2xl px-5 py-4">
          <p className="text-sm text-center text-foreground">
            L&apos;intérêt pour un approfondissement a été enregistré localement avec ce tirage.
          </p>
        </div>
      )}
    </>
  );
};

export default HomePage;

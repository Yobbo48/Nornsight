import path from 'node:path';
import { existsSync, readFileSync } from 'node:fs';

const ENV_PATHS = [
  path.resolve(process.cwd(), '.env'),
  path.resolve(process.cwd(), '../../.env'),
  path.resolve(process.cwd(), '../.env')
];

function readEnvFile() {
  for (const envPath of ENV_PATHS) {
    if (!existsSync(envPath)) {
      continue;
    }

    const content = readFileSync(envPath, 'utf-8');
    return Object.fromEntries(
      content
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line && !line.startsWith('#') && line.includes('='))
        .map((line) => {
          const separatorIndex = line.indexOf('=');
          const key = line.slice(0, separatorIndex).trim();
          const rawValue = line.slice(separatorIndex + 1).trim();
          return [key, rawValue.replace(/^['"]|['"]$/g, '')];
        })
    );
  }

  return {};
}

const fileEnv = readEnvFile();

export function getConfigValue(key, fallback = '') {
  return process.env[key] || fileEnv[key] || fallback;
}

export function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

export function getAdminEmails() {
  return getConfigValue('ADMIN_EMAILS', '')
    .split(',')
    .map((value) => normalizeEmail(value))
    .filter(Boolean);
}

export function isAdminEmail(email) {
  return getAdminEmails().includes(normalizeEmail(email));
}

export function getMysqlConfig() {
  const host = getConfigValue('MYSQL_HOST', 'localhost');
  const user = getConfigValue('MYSQL_USER');
  const password = getConfigValue('MYSQL_PASSWORD');
  const database = getConfigValue('MYSQL_DATABASE');
  const port = Number(getConfigValue('MYSQL_PORT', '3306'));

  return {
    host,
    user,
    password,
    database,
    port,
    enabled: Boolean(host && user && password && database)
  };
}

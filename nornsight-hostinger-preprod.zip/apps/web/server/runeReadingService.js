import path from 'node:path';
import { existsSync, readFileSync } from 'node:fs';
import {
  buildSummaryUserPrompt,
  buildFullReadingUserPrompt,
  buildTeaserUserPrompt,
  createFreeReadingSummary,
  createFullReadingFallback,
  createTeaserFallback,
  DEFAULT_OPENAI_MODEL,
  FULL_READING_SYSTEM_PROMPT,
  SUMMARY_SYSTEM_PROMPT,
  TEASER_SYSTEM_PROMPT
} from '../src/lib/runeReadingPrompt.js';

const OPENAI_API_URL = 'https://api.openai.com/v1/responses';
const ENV_PATHS = [
  path.resolve(process.cwd(), '.env'),
  path.resolve(process.cwd(), '../../.env'),
  path.resolve(process.cwd(), '../.env')
];

const MODE_CONFIG = {
  summary: {
    instructions: SUMMARY_SYSTEM_PROMPT,
    buildPrompt: buildSummaryUserPrompt,
    fallback: createFreeReadingSummary,
    maxOutputTokens: 120,
    minWords: 70,
    maxWords: 110
  },
  teaser: {
    instructions: TEASER_SYSTEM_PROMPT,
    buildPrompt: buildTeaserUserPrompt,
    fallback: createTeaserFallback,
    maxOutputTokens: 120,
    minWords: 50,
    maxWords: 85
  },
  full: {
    instructions: FULL_READING_SYSTEM_PROMPT,
    buildPrompt: buildFullReadingUserPrompt,
    fallback: createFullReadingFallback,
    maxOutputTokens: 260,
    minWords: 140,
    maxWords: 220
  }
};

function readEnvFile() {
  for (const envPath of ENV_PATHS) {
    if (!existsSync(envPath)) {
      continue;
    }

    const content = readFileSync(envPath, 'utf-8');
    return Object.fromEntries(
      content
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line && !line.startsWith('#') && line.includes('='))
        .map((line) => {
          const separatorIndex = line.indexOf('=');
          const key = line.slice(0, separatorIndex).trim();
          const rawValue = line.slice(separatorIndex + 1).trim();
          return [key, rawValue.replace(/^['"]|['"]$/g, '')];
        })
    );
  }

  return {};
}

const fileEnv = readEnvFile();

function getConfigValue(key, fallback = '') {
  return process.env[key] || fileEnv[key] || fallback;
}

function extractText(responseJson) {
  if (typeof responseJson.output_text === 'string' && responseJson.output_text.trim()) {
    return responseJson.output_text.trim();
  }

  const outputItems = Array.isArray(responseJson.output) ? responseJson.output : [];

  for (const item of outputItems) {
    const content = Array.isArray(item.content) ? item.content : [];

    for (const part of content) {
      if (typeof part.text === 'string' && part.text.trim()) {
        return part.text.trim();
      }
    }
  }

  return '';
}

function countWords(text) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

function normalizeText(text) {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function sanitizeReading(text) {
  return String(text || '')
    .replace(/\r/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\s+([,;:.!?])/g, '$1')
    .replace(/([«“])\s+/g, '$1')
    .replace(/\s+([»”])/g, '$1')
    .replace(/\bCa\b/g, 'Ça')
    .replace(/\bca\b/g, 'ça')
    .replace(/\bEtre\b/g, 'Être')
    .replace(/\betre\b/g, 'être')
    .replace(/\bMeme\b/g, 'Même')
    .replace(/\bmeme\b/g, 'même')
    .replace(/\bTres\b/g, 'Très')
    .replace(/\btres\b/g, 'très')
    .replace(/\bDecaler\b/g, 'Décaler')
    .replace(/\bdecaler\b/g, 'décaler')
    .replace(/\bRealite\b/g, 'Réalité')
    .replace(/\brealite\b/g, 'réalité')
    .replace(/\bPrecision\b/g, 'Précision')
    .replace(/\bprecision\b/g, 'précision')
    .replace(/\bNoeud\b/g, 'Nœud')
    .replace(/\bnoeud\b/g, 'nœud')
    .replace(/\bcoeur\b/g, 'cœur')
    .replace(/\bCoeur\b/g, 'Cœur')
    .replace(/\bc[’']est\b/g, 'c’est')
    .replace(/\bC[’']est\b/g, 'C’est')
    .replace(/\bd[’']abord\b/g, 'd’abord')
    .replace(/\bD[’']abord\b/g, 'D’abord')
    .replace(/\bl[’']instant\b/g, 'l’instant')
    .replace(/\bL[’']instant\b/g, 'L’instant')
    .replace(/\bl[’']enjeu\b/g, 'l’enjeu')
    .replace(/\bL[’']enjeu\b/g, 'L’enjeu')
    .replace(/\bn[’']est\b/g, 'n’est')
    .replace(/\bN[’']est\b/g, 'N’est')
    .replace(/\bjusqu[’']a\b/g, 'jusqu’à')
    .replace(/\bJusqu[’']a\b/g, 'Jusqu’à')
    .replace(/\bpresqu[’']a\b/g, 'presqu’à')
    .replace(/\bqu[’']il\b/g, 'qu’il')
    .replace(/\bQu[’']il\b/g, 'Qu’il')
    .replace(/\bs[’']il\b/g, 's’il')
    .replace(/\bS[’']il\b/g, 'S’il')
    .replace(/\bA ce stade\b/g, 'À ce stade')
    .replace(/\bA cet endroit\b/g, 'À cet endroit')
    .replace(/\bA ce moment\b/g, 'À ce moment')
    .replace(/\bA partir\b/g, 'À partir')
    .replace(/\bA travers\b/g, 'À travers')
    .replace(/\bA force\b/g, 'À force')
    .replace(/\bA l['’]/g, 'À l’')
    .replace(/\bA la fois\b/g, 'À la fois')
    .trim();
}

function endsCleanly(text) {
  return /[.!?…]$/.test(text.trim());
}

function endsWithQuestion(text) {
  return /\?\s*$/.test(text.trim());
}

function looksMechanicalTeaser(text) {
  const lowered = normalizeText(text);
  return [
    'par rapport a ta question sur',
    'montre que',
    'signale que',
    'ouvre une voie',
    'on voit que',
    'decouvrons ensemble',
    'secret',
    'energie',
    'invite a',
    'rappelle que',
    'murmure que',
    'souffle',
    'feu interieur',
    'renouveau',
    'harmonie',
    'carrefour',
    'labyrinthe',
    'echo',
    'resonance',
    'voie vers',
    'tu te retrouves',
    'tu te trouves a un moment ou',
    'ce qui se dessine',
    'la question de',
    'la dynamique montre'
  ].some((snippet) => lowered.includes(snippet));
}

function looksMechanicalSummary(text) {
  const lowered = normalizeText(text);
  return [
    'montre que',
    'indique que',
    'ouvre une voie',
    'par rapport a ta question sur',
    'energie',
    'on voit que',
    'souffle',
    'harmonie',
    'carrefour',
    'labyrinthe',
    'ce qui se dessine',
    'la question de',
    'la dynamique montre'
  ].some((snippet) => lowered.includes(snippet));
}

function looksMechanicalFull(text) {
  const lowered = normalizeText(text);
  return [
    'par rapport a ta question sur',
    'cette rune',
    'ces runes',
    'montre que',
    'indique que',
    'ouvre une voie',
    'energie',
    'souffle',
    'feu interieur',
    'renouveau',
    'harmonie',
    'carrefour',
    'labyrinthe',
    'echo',
    'resonance',
    'tu te retrouves',
    'tu te trouves a un moment ou',
    'ce qui se dessine',
    'la question de',
    'la dynamique montre',
    'tu vois deja ce qui est en train de se jouer',
    'une part de la situation',
    'le point sensible se situe la'
  ].some((snippet) => lowered.includes(snippet));
}

function hasPronounShift(text) {
  const lowered = normalizeText(text);
  return /\bvous\b/.test(lowered) || /\bvotre\b/.test(lowered) || /\bvos\b/.test(lowered);
}

function hasGenericCoachingQuestion(text) {
  const lowered = normalizeText(text);
  return [
    'es tu pret a',
    'es-tu pret a',
    'veux tu',
    'veux-tu',
    'jusqu ou es tu pret',
    'jusqu’ou es tu pret',
    'quelle part de cette retenue',
    'quelle question reste a explorer'
  ].some((snippet) => lowered.includes(snippet));
}

function mentionsRuneNames(text, runes) {
  const lowered = normalizeText(text);
  return runes.some((rune) => lowered.includes(normalizeText(String(rune?.nom || ''))));
}

function looksSegmentedReading(text) {
  const lowered = normalizeText(text);
  return [
    'dynamique actuelle',
    'point sensible',
    'mouvement possible',
    'passe',
    'présent',
    'present',
    'futur',
    'd abord',
    'ensuite',
    'enfin'
  ].some((snippet) => lowered.includes(snippet));
}

function extractQuestionAnchors(question) {
  const lowered = normalizeText(question);
  const stopWords = new Set([
    'alors', 'avec', 'avoir', 'comment', 'dans', 'depuis', 'dois', 'doit', 'donc', 'elle', 'elles',
    'entre', 'etre', 'faire', 'mais', 'meme', 'mon', 'plus', 'pour', 'pourquoi', 'quand', 'quel',
    'quelle', 'quelles', 'quels', 'quoi', 'sans', 'sera', 'serait', 'sont', 'sur', 'toi', 'ton',
    'tout', 'tres', 'une', 'vers', 'vais', 'vrai', 'vraie', 'vraiment', 'ou', 'pas', 'qui',
    'cela', 'ca', 'situation', 'traverse', 'traverses', 'moment', 'question'
  ]);

  return [...new Set(
    lowered
      .split(/[^a-z0-9]+/)
      .filter((token) => token.length >= 4 && !stopWords.has(token))
  )].slice(0, 6);
}

function lacksConcreteAnchor(text, question) {
  const anchors = extractQuestionAnchors(question);

  if (!anchors.length) {
    return false;
  }

  const lowered = normalizeText(text);
  return !anchors.some((anchor) => lowered.includes(anchor));
}

function lacksDomainAnchor(text, question) {
  const loweredQuestion = normalizeText(question);
  const loweredText = normalizeText(text);

  const domainChecks = [
    {
      triggers: ['financ', 'argent', 'revenu', 'client', 'clients'],
      required: ['financ', 'argent', 'revenu', 'client', 'clients', 'stable', 'stabil', 'materiel', 'materielle']
    },
    {
      triggers: ['projet', 'projets', 'activite', 'activité', 'video', 'videos', 'reseaux', 'réseaux'],
      required: ['projet', 'projets', 'activite', 'activité', 'video', 'videos', 'visibil', 'regulier', 'reguli', 'tenir', 'rythme']
    },
    {
      triggers: ['couple', 'relation', 'amour', 'mari', 'femme', 'lien'],
      required: ['relation', 'lien', 'couple', 'attache', 'reciproc', 'clarte', 'distance']
    }
  ];

  for (const rule of domainChecks) {
    if (rule.triggers.some((token) => loweredQuestion.includes(token))) {
      return !rule.required.some((token) => loweredText.includes(token));
    }
  }

  return false;
}

function validateReading(text, mode, runes = [], question = '') {
  const config = MODE_CONFIG[mode];
  const wordCount = countWords(text);

  if (!text || !endsCleanly(text)) {
    return false;
  }

  if (wordCount < config.minWords || wordCount > config.maxWords) {
    return false;
  }

  if (mode === 'teaser' && looksMechanicalTeaser(text)) {
    return false;
  }

  if (mode === 'teaser' && (mentionsRuneNames(text, runes) || looksSegmentedReading(text))) {
    return false;
  }

  if (mode === 'summary' && looksMechanicalSummary(text)) {
    return false;
  }

  if (mode === 'summary' && mentionsRuneNames(text, runes)) {
    return false;
  }

  if (mode === 'summary' && lacksConcreteAnchor(text, question)) {
    return false;
  }

  if (mode === 'summary' && lacksDomainAnchor(text, question)) {
    return false;
  }

  if (mode === 'full' && looksMechanicalFull(text)) {
    return false;
  }

  if (mode === 'full' && mentionsRuneNames(text, runes)) {
    return false;
  }

  if (mode === 'full' && !endsWithQuestion(text)) {
    return false;
  }

  if (mode === 'full' && (hasPronounShift(text) || hasGenericCoachingQuestion(text))) {
    return false;
  }

  if ((mode === 'teaser' || mode === 'full') && lacksConcreteAnchor(text, question)) {
    return false;
  }

  if ((mode === 'teaser' || mode === 'full') && lacksDomainAnchor(text, question)) {
    return false;
  }

  return true;
}

export function validateRuneReadingInput(payload) {
  const question = typeof payload?.question === 'string' ? payload.question.trim() : '';
  const runes = Array.isArray(payload?.runes) ? payload.runes : [];
  const mode = ['summary', 'teaser', 'full'].includes(payload?.mode) ? payload.mode : 'teaser';

  if (!question) {
    throw new Error('La question est requise.');
  }

  if (runes.length !== 3) {
    throw new Error('Le tirage doit contenir exactement 3 runes.');
  }

  return { question, runes, mode };
}

async function requestReading({ apiKey, question, runes, mode }) {
  const config = MODE_CONFIG[mode];
  const response = await fetch(OPENAI_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: getConfigValue('OPENAI_MODEL', DEFAULT_OPENAI_MODEL),
      temperature: 0.7,
      max_output_tokens: config.maxOutputTokens,
      instructions: config.instructions,
      input: [
        {
          role: 'user',
          content: [
            {
              type: 'input_text',
              text: config.buildPrompt({ question, runes })
            }
          ]
        }
      ]
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`OpenAI API error: ${response.status} ${errorText}`);
  }

  const responseJson = await response.json();

  if (responseJson?.refusal) {
    throw new Error('Le modele a refuse de produire une lecture pour cette demande.');
  }

  return extractText(responseJson);
}

export async function createRuneReading(payload) {
  const apiKey = getConfigValue('OPENAI_API_KEY');

  if (!apiKey) {
    throw new Error('OPENAI_API_KEY is missing.');
  }

  const { question, runes, mode } = validateRuneReadingInput(payload);
  const config = MODE_CONFIG[mode];

  for (let attempt = 0; attempt < 3; attempt += 1) {
    const reading = sanitizeReading(await requestReading({ apiKey, question, runes, mode }));

    if (validateReading(reading, mode, runes, question) || attempt === 2) {
      return validateReading(reading, mode, runes, question) ? reading : config.fallback({ question, runes });
    }
  }
}

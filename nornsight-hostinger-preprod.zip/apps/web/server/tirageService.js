import {
  createFreeReadingSummary,
  createTeaserFallback
} from '../src/lib/runeReadingPrompt.js';
import { getDrawingRepository } from './data/drawingRepository.js';
import { isAdminEmail, normalizeEmail } from './config/env.js';
import { drawRunes } from './runeDrawService.js';
import { createRuneReading } from './runeReadingService.js';
import { hashValue, normalizeQuestion } from './utils/hash.js';

const FULL_READING_COOLDOWN_MS = 24 * 60 * 60 * 1000;

function serializeRunes(runes) {
  return runes.map((rune) => ({
    symbole: rune.symbole,
    nom: rune.nom,
    positionKey: rune.positionKey,
    positionLabel: rune.positionLabel,
    interpretation: rune.interpretation,
    detailedInterpretation: rune.detailedInterpretation,
    essenceSummary: rune.essenceSummary,
    essenceKeywords: rune.essenceKeywords
  }));
}

function buildQuestionFingerprint(question) {
  return hashValue(normalizeQuestion(question));
}

function buildIpFingerprint(requestIp) {
  return hashValue(String(requestIp || 'unknown').trim());
}

function buildReadingSnapshot({ runes, summary, teaser, fullReading }) {
  return {
    runes: serializeRunes(runes),
    freeReadingSummary: summary,
    teaserReading: teaser,
    fullReading
  };
}

export async function createFreeTirage({ question, requestIp }) {
  const trimmedQuestion = String(question || '').trim();

  if (!trimmedQuestion) {
    throw new Error('La question est requise.');
  }

  const runes = drawRunes();
  const summary = createFreeReadingSummary({ runes, question: trimmedQuestion });

  let teaser = '';
  try {
    teaser = await createRuneReading({ question: trimmedQuestion, runes, mode: 'teaser' });
  } catch (error) {
    console.error('Error generating teaser for free tirage:', error);
    teaser = createTeaserFallback({ question: trimmedQuestion, runes });
  }

  const now = new Date().toISOString();
  const record = {
    id: `tirage_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    question: trimmedQuestion,
    questionFingerprint: buildQuestionFingerprint(trimmedQuestion),
    ipFingerprint: buildIpFingerprint(requestIp),
    createdAt: now,
    updatedAt: now,
    status: 'free',
    runes: serializeRunes(runes),
    interpretation: buildReadingSnapshot({
      runes,
      summary,
      teaser,
      fullReading: ''
    })
  };

  const repository = await getDrawingRepository();
  await repository.saveDrawing(record);

  return {
    tirageId: record.id,
    question: trimmedQuestion,
    runes,
    summary,
    teaser
  };
}

export async function unlockFullTirage({
  tirageId,
  email,
  question,
  runes,
  freeReadingSummary,
  teaserReading,
  requestIp
}) {
  const trimmedQuestion = String(question || '').trim();
  const normalizedEmail = normalizeEmail(email);
  const adminBypass = isAdminEmail(normalizedEmail);

  if (!normalizedEmail || !trimmedQuestion || !Array.isArray(runes) || runes.length !== 3) {
    throw new Error('Les informations du tirage sont incomplètes.');
  }

  const now = Date.now();
  const questionFingerprint = buildQuestionFingerprint(trimmedQuestion);
  const ipFingerprint = buildIpFingerprint(requestIp);
  const repository = await getDrawingRepository();
  const recentUnlock = adminBypass
    ? null
    : await repository.findRecentUnlock({
        questionFingerprint,
        emailNormalized: normalizedEmail,
        ipFingerprint,
        since: now - FULL_READING_COOLDOWN_MS
      });

  if (recentUnlock) {
    if (
      recentUnlock.emailNormalized === normalizedEmail &&
      recentUnlock.interpretation?.fullReading
    ) {
      return {
        status: 'unlocked',
        tirageId: recentUnlock.id,
        reading: recentUnlock.interpretation.fullReading,
        reused: true
      };
    }

    return {
      status: 'blocked',
      message:
        'Une lecture complète a déjà été demandée pour cette question depuis cette adresse email ou cette connexion au cours des dernières 24 heures. Tu pourras en demander une nouvelle demain.'
    };
  }

  const reading = await createRuneReading({
    question: trimmedQuestion,
    runes,
    mode: 'full'
  });

  const timestamp = new Date().toISOString();
  const record = {
    id: tirageId || `tirage_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    email: normalizedEmail,
    emailNormalized: normalizedEmail,
    question: trimmedQuestion,
    questionFingerprint,
    ipFingerprint,
    createdAt: timestamp,
    updatedAt: timestamp,
    fullUnlockedAt: timestamp,
    status: 'unlocked',
    runes: serializeRunes(runes),
    interpretation: buildReadingSnapshot({
      runes,
      summary: freeReadingSummary,
      teaser: teaserReading,
      fullReading: reading
    })
  };

  await repository.saveDrawing(record);

  return {
    status: 'unlocked',
    tirageId: record.id,
    reading,
    isAdminBypass: adminBypass
  };
}

export async function saveTirageEmail({ tirageId, email }) {
  const normalizedEmail = normalizeEmail(email);

  if (!tirageId || !normalizedEmail) {
    throw new Error('Le tirage et l’email sont requis.');
  }

  const repository = await getDrawingRepository();
  const record = await repository.findDrawingById(tirageId);

  if (!record) {
    throw new Error('Tirage introuvable.');
  }

  const nextRecord = {
    ...record,
    email: normalizedEmail,
    emailNormalized: normalizedEmail,
    updatedAt: new Date().toISOString()
  };

  await repository.saveDrawing(nextRecord);

  return {
    status: 'saved',
    tirageId,
    email: normalizedEmail,
    isAdminEmail: isAdminEmail(normalizedEmail)
  };
}

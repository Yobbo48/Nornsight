import runeData from '../src/data/runeData.js';
import {
  POSITION_KEYS,
  POSITION_LABELS,
  getPositionSourceKey,
  buildPositionInterpretation
} from '../src/lib/runePositions.js';

export function drawRunes() {
  const shuffled = [...runeData].sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, 3);

  return selected.map((rune, index) => {
    const positionKey = POSITION_KEYS[index];
    const sourceKey = getPositionSourceKey(positionKey, index);
    const positionInterpretations = rune.interpretations[positionKey] || [];
    const randomIndex = Math.floor(Math.random() * positionInterpretations.length);

    return {
      symbole: rune.symbole,
      nom: rune.nom,
      positionKey,
      positionSourceKey: sourceKey,
      positionLabel: POSITION_LABELS[index],
      interpretation: buildPositionInterpretation(
        positionKey,
        sourceKey,
        rune.referential.positions[sourceKey].summary
      ),
      detailedInterpretation: positionInterpretations[randomIndex],
      essenceSummary: rune.essence.summary,
      essenceKeywords: rune.essence.keywords,
      referential: rune.referential
    };
  });
}


const runeData = [
  {
    symbole: 'ᚠ',
    nom: 'Fehu',
    interpretations: [
      'Quelque chose en toi cherche à circuler, mais tu le retiens. Ce que tu as construit demande maintenant à être mis en mouvement, pas seulement préservé.',
      'Tu es dans une phase où ce que tu possèdes te possède un peu. La sécurité que tu as créée commence à peser plus qu\'elle ne te libère.',
      'Il y a une tension entre garder ce qui est stable et prendre le risque de le transformer. Tu sens que l\'un ou l\'autre ne suffit plus.'
    ]
  },
  {
    symbole: 'ᚢ',
    nom: 'Uruz',
    interpretations: [
      'Une force brute monte en toi, mais elle ne sait pas encore où aller. Tu as l\'énergie, mais pas encore la direction claire.',
      'Tu sens que tu pourrais tout renverser, mais quelque chose te retient. Cette puissance en toi attend d\'être canalisée, pas réprimée.',
      'Il y a une vitalité qui cherche à s\'exprimer, mais elle se disperse. Tu as besoin de choisir un seul point de focus pour que cette force devienne création.'
    ]
  },
  {
    symbole: 'ᚦ',
    nom: 'Thurisaz',
    interpretations: [
      'Ce qui te résiste n\'est pas ton ennemi. C\'est ce qui te force à choisir consciemment au lieu de suivre le chemin de moindre résistance.',
      'Tu te bats contre quelque chose qui pourrait être un allié si tu changeais de perspective. L\'obstacle te montre où tu dois devenir plus fort.',
      'Il y a une friction qui te fatigue, mais elle révèle aussi ce qui compte vraiment pour toi. Sans elle, tu ne saurais pas ce que tu es prêt à défendre.'
    ]
  },
  {
    symbole: 'ᚨ',
    nom: 'Ansuz',
    interpretations: [
      'Quelque chose veut se dire, mais tu ne l\'entends pas encore. Trop de bruit, trop de certitudes. Le message est là, mais il attend que tu fasses silence.',
      'Tu cherches des réponses à l\'extérieur alors qu\'une vérité émerge déjà en toi. Elle est discrète, mais elle insiste.',
      'Il y a une clarté qui veut venir, mais tu la bloques sans t\'en rendre compte. Peut-être parce que tu sais déjà ce qu\'elle va te demander.'
    ]
  },
  {
    symbole: 'ᚱ',
    nom: 'Raido',
    interpretations: [
      'Tu es en mouvement, mais tu résistes au rythme naturel. Tu veux contrôler chaque étape au lieu de te laisser porter par le processus.',
      'Ce voyage n\'est pas seulement physique. Quelque chose en toi est en train de changer, même si tu ne le vois pas encore clairement.',
      'Tu traverses une transition, mais tu t\'accroches à l\'ancien. Le chemin se révèle seulement quand tu acceptes de lâcher ce que tu connais.'
    ]
  },
  {
    symbole: 'ᚲ',
    nom: 'Kenaz',
    interpretations: [
      'Une lumière s\'allume sur ce que tu préférais ne pas voir. Cette clarté est inconfortable, mais elle te libère d\'une illusion.',
      'Tu commences à voir la situation telle qu\'elle est, pas telle que tu voudrais qu\'elle soit. C\'est dérangeant, mais nécessaire.',
      'Quelque chose se révèle, et tu ne peux plus faire semblant de ne pas savoir. La question maintenant est : qu\'est-ce que tu vas faire avec cette vérité ?'
    ]
  },
  {
    symbole: 'ᚷ',
    nom: 'Gebo',
    interpretations: [
      'Il y a un déséquilibre entre ce que tu donnes et ce que tu reçois. Tu le sens, mais tu ne sais pas encore comment le rééquilibrer.',
      'Tu donnes beaucoup, peut-être trop. Mais ce n\'est pas de la générosité si ça te vide. L\'échange véritable nourrit les deux côtés.',
      'Tu as du mal à recevoir sans culpabilité. Comme si accepter quelque chose diminuait ta valeur. Mais l\'équilibre demande les deux mouvements.'
    ]
  },
  {
    symbole: 'ᚹ',
    nom: 'Wunjo',
    interpretations: [
      'Tu cherches la joie ailleurs alors qu\'elle est déjà là, sous une forme différente de celle que tu imaginais.',
      'Il y a une harmonie qui se dessine, mais tu ne la vois pas parce que tu attends quelque chose de plus spectaculaire.',
      'Ce qui fonctionne déjà dans ta vie demande à être reconnu. Le bonheur n\'est pas une destination, c\'est une pratique quotidienne.'
    ]
  },
  {
    symbole: 'ᚺ',
    nom: 'Hagalaz',
    interpretations: [
      'Quelque chose se brise, et tu t\'accroches aux débris. Mais ce qui s\'effondre n\'était pas aussi solide que tu le croyais.',
      'Cette rupture fait de la place. Tu ne le vois pas encore, mais ce qui doit rester reviendra sous une forme plus vraie.',
      'Tu résistes à laisser partir, mais ta résistance prolonge la douleur. Certaines choses doivent se briser pour que tu puisses reconstruire.'
    ]
  },
  {
    symbole: 'ᚾ',
    nom: 'Nauthiz',
    interpretations: [
      'La contrainte te révèle des ressources que tu ignorais avoir. Ce manque te force à devenir créatif au lieu de rester dans le confort.',
      'Tu te vois comme victime de la situation, mais tu as plus de pouvoir que tu ne le crois. La limitation est aussi une opportunité.',
      'Ce qui te manque te montre ce qui compte vraiment. Sans cette nécessité, tu ne saurais pas ce que tu es capable de faire.'
    ]
  },
  {
    symbole: 'ᛁ',
    nom: 'Isa',
    interpretations: [
      'Tout est figé, et tu t\'impatientes. Mais cette pause n\'est pas un blocage, c\'est une cristallisation nécessaire.',
      'Tu veux forcer le mouvement, mais le temps n\'est pas venu. Quelque chose doit se clarifier avant que tu puisses avancer.',
      'L\'immobilité te dérange parce qu\'elle te force à être avec toi-même. Mais c\'est exactement ce dont tu as besoin maintenant.'
    ]
  },
  {
    symbole: 'ᛃ',
    nom: 'Jera',
    interpretations: [
      'Un cycle arrive à maturité, mais tu veux des résultats immédiats. Tu ne respectes pas le rythme naturel des choses.',
      'Ce que tu as semé il y a longtemps est prêt à être récolté. Mais seulement si tu continues à faire ta part sans forcer.',
      'Tu es dans le bon timing, mais tu ne le vois pas. Chaque saison a son rôle, et celle-ci demande de la patience.'
    ]
  },
  {
    symbole: 'ᛇ',
    nom: 'Eihwaz',
    interpretations: [
      'Deux forces opposées te tirent dans des directions différentes. Tu veux choisir un camp, mais la solution est dans l\'intégration.',
      'Cette tension est inconfortable, mais elle est créative. Ce qui te déchire pourrait aussi te transformer si tu acceptes de tenir les deux pôles.',
      'Tu cherches à résoudre la contradiction trop vite. Mais certaines choses ne se résolvent pas, elles se vivent.'
    ]
  },
  {
    symbole: 'ᛈ',
    nom: 'Perthro',
    interpretations: [
      'Tu es face à quelque chose que tu ne peux pas encore comprendre. Ton besoin de contrôle te paralyse plus qu\'il ne te protège.',
      'Il y a un mystère qui se dévoile lentement. Tu veux tout savoir maintenant, mais certaines choses se révèlent seulement en avançant.',
      'L\'incertitude te fait peur, mais elle fait partie du chemin. Accepter de ne pas savoir est parfois la seule façon d\'avancer.'
    ]
  },
  {
    symbole: 'ᛉ',
    nom: 'Algiz',
    interpretations: [
      'Tu es protégé, mais cette protection demande ta vigilance. Tu baisses ta garde au mauvais moment.',
      'Il y a une confusion entre ouverture et naïveté. Tu laisses entrer ce qui devrait rester dehors.',
      'Tes limites sont floues. Tu as besoin de clarifier ce qui est acceptable et ce qui ne l\'est pas, sans culpabilité.'
    ]
  },
  {
    symbole: 'ᛊ',
    nom: 'Sowilo',
    interpretations: [
      'Une clarté totale émerge, mais tu détournes le regard. La vérité te dérange parce qu\'elle te demande de changer.',
      'Tu vois enfin la situation telle qu\'elle est. Cette lumière peut être aveuglante, mais elle te libère d\'une illusion.',
      'Quelque chose devient évident, et tu ne peux plus faire semblant. La question est : qu\'est-ce que tu vas faire avec cette clarté ?'
    ]
  },
  {
    symbole: 'ᛏ',
    nom: 'Tiwaz',
    interpretations: [
      'Un combat se présente, mais tu dois vérifier s\'il est juste. Toutes les batailles ne méritent pas ton énergie.',
      'Tu te bats pour les mauvaises raisons. Ton combat est nourri par la peur ou l\'orgueil, pas par la vérité.',
      'Il y a quelque chose qui mérite d\'être défendu, mais tu dois le faire avec intégrité, pas avec domination.'
    ]
  },
  {
    symbole: 'ᛒ',
    nom: 'Berkano',
    interpretations: [
      'Quelque chose de nouveau germe en toi, mais tu imposes trop de contrôle. Tu étouffes ce qui veut naître.',
      'Une croissance se fait en silence. Tu ne la vois pas encore, mais elle est là. Elle demande de la douceur, pas de la force.',
      'Tu veux des résultats visibles, mais la naissance a son propre rythme. Crée les conditions favorables et laisse faire.'
    ]
  },
  {
    symbole: 'ᛖ',
    nom: 'Ehwaz',
    interpretations: [
      'Un partenariat se forme, mais tu veux tout faire seul. Tu ne fais pas confiance à l\'autre pour porter sa part.',
      'Il y a une collaboration possible, mais ton besoin de contrôle la sabote. Deux forces alignées vont plus loin qu\'une seule.',
      'Tu résistes à co-créer parce que ça demande de lâcher prise. Mais certaines choses ne peuvent se faire qu\'à deux.'
    ]
  },
  {
    symbole: 'ᛗ',
    nom: 'Mannaz',
    interpretations: [
      'Tu es face à toi-même, et ce que tu vois te dérange. Il y a une distance entre qui tu es et qui tu prétends être.',
      'Tu joues un personnage pour correspondre aux attentes. Mais cette conformité te coûte plus cher que tu ne le crois.',
      'Une question d\'authenticité se pose. Oser être toi-même, même si ça dérange, est la seule voie qui tient sur la durée.'
    ]
  },
  {
    symbole: 'ᛚ',
    nom: 'Laguz',
    interpretations: [
      'Un flux émotionnel te traverse, et tu te laisses submerger. Tu confonds ressentir et être emporté.',
      'Tes émotions montent et descendent, mais tu n\'as pas encore appris à nager dedans. Tu te noies dans ce qui devrait te guider.',
      'Il y a une fluidité naturelle, mais tu luttes contre elle. L\'eau te montre le chemin si tu cesses de résister.'
    ]
  },
  {
    symbole: 'ᛜ',
    nom: 'Ingwaz',
    interpretations: [
      'Quelque chose a mûri en silence, et c\'est prêt à naître. Mais tu le retiens par peur de l\'inconnu.',
      'Une gestation arrive à terme. Tu sens que c\'est le moment, mais tu prolonges au-delà du nécessaire.',
      'Ce qui doit venir au monde trouvera son chemin. Ton rôle est de laisser faire, pas de contrôler le processus.'
    ]
  },
  {
    symbole: 'ᛟ',
    nom: 'Othala',
    interpretations: [
      'Tu es connecté à tes racines, mais tu portes aussi des fardeaux qui ne sont pas les tiens. Il faut trier.',
      'Un héritage te soutient, mais il peut aussi t\'emprisonner. Tu confonds honorer et répéter.',
      'Les fondations sont là, mais tu dois construire ta propre maison. Prends ce qui te nourrit, laisse ce qui t\'alourdit.'
    ]
  },
  {
    symbole: 'ᛞ',
    nom: 'Dagaz',
    interpretations: [
      'Un basculement se produit. Tu es au seuil d\'une transformation majeure, mais tu résistes au changement de paradigme.',
      'Quelque chose meurt en toi pour faire place à quelque chose de plus vaste. Cette mort est nécessaire.',
      'Tu es en train de franchir un seuil, même si tu ne le vois pas encore. L\'ancienne version ne peut plus tenir.'
    ]
  }
];

export default runeData;

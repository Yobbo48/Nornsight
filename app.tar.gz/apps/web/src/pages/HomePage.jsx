
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import runeData from '@/data/runeData.js';

const POSITION_LABELS = ['Dynamique actuelle', 'Point sensible', 'Mouvement possible'];

const HomePage = () => {
  const [phase, setPhase] = useState('question');
  const [question, setQuestion] = useState('');
  const [drawnRunes, setDrawnRunes] = useState([]);
  const [revealedCards, setRevealedCards] = useState([false, false, false]);
  const [loadingText, setLoadingText] = useState('Connexion aux runes...');
  const [email, setEmail] = useState('');
  const [emailSaved, setEmailSaved] = useState(false);

  useEffect(() => {
    const savedState = localStorage.getItem('nornsight_current_state');
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        if (parsed.phase && parsed.question && parsed.drawnRunes) {
          setPhase(parsed.phase);
          setQuestion(parsed.question);
          setDrawnRunes(parsed.drawnRunes);
        }
      } catch (error) {
        console.error('Error loading saved state:', error);
      }
    }
  }, []);

  const saveCurrentState = (newPhase, newQuestion, newRunes) => {
    const state = {
      phase: newPhase,
      question: newQuestion,
      drawnRunes: newRunes
    };
    localStorage.setItem('nornsight_current_state', JSON.stringify(state));
  };

  const drawRunes = () => {
    const shuffled = [...runeData].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, 3);

    const runesWithInterpretations = selected.map((rune) => {
      const randomIndex = Math.floor(Math.random() * rune.interpretations.length);
      return {
        symbole: rune.symbole,
        nom: rune.nom,
        interpretation: rune.interpretations[randomIndex]
      };
    });

    return runesWithInterpretations;
  };

  const handleQuestionSubmit = (e) => {
    e.preventDefault();
    if (question.trim()) {
      const runes = drawRunes();
      setDrawnRunes(runes);
      setPhase('revealing');
      saveCurrentState('revealing', question.trim(), runes);

      setTimeout(() => {
        setLoadingText('Lecture en cours...');
      }, 1500);

      setTimeout(() => {
        setRevealedCards([true, false, false]);
      }, 3000);

      setTimeout(() => {
        setRevealedCards([true, true, false]);
      }, 4500);

      setTimeout(() => {
        setRevealedCards([true, true, true]);
      }, 6000);

      setTimeout(() => {
        setPhase('results');
        saveCurrentState('results', question.trim(), runes);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 7500);
    }
  };

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    if (email.trim()) {
      const tirage = {
        email: email.trim(),
        question,
        runes: drawnRunes,
        date: Date.now(),
        status: 'saved'
      };

      try {
        const existingTirages = JSON.parse(localStorage.getItem('nornsight_tirages') || '[]');
        existingTirages.push(tirage);
        localStorage.setItem('nornsight_tirages', JSON.stringify(existingTirages));
        setEmailSaved(true);
      } catch (error) {
        console.error('Error saving to localStorage:', error);
      }
    }
  };

  const handleNewDraw = () => {
    setPhase('question');
    setQuestion('');
    setDrawnRunes([]);
    setRevealedCards([false, false, false]);
    setLoadingText('Connexion aux runes...');
    setEmail('');
    setEmailSaved(false);
    localStorage.removeItem('nornsight_current_state');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>Nornsight - Un regard clair sur ce que tu traverses</title>
        <meta name="description" content="Tirage de runes pour éclairer ta situation présente" />
      </Helmet>

      <div className="min-h-screen bg-[#0a0a0a] text-foreground relative overflow-hidden">
        <div className="relative z-10">
          <AnimatePresence mode="wait">
            {phase === 'question' && (
              <motion.div
                key="question"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
                className="min-h-screen flex items-center justify-center px-4 py-20"
              >
                <div className="max-w-2xl w-full">
                  <motion.h1
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    className="font-['Cinzel'] text-5xl md:text-6xl lg:text-7xl font-bold text-center mb-12 text-glow"
                    style={{ letterSpacing: '-0.02em' }}
                  >
                    Nornsight
                  </motion.h1>

                  <motion.h2
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className="font-['Cinzel'] text-3xl md:text-4xl font-semibold text-center mb-6"
                    style={{ letterSpacing: '-0.02em' }}
                  >
                    Quelle est ta question ou la situation que tu traverses ?
                  </motion.h2>

                  <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.4 }}
                    className="text-lg text-center text-muted-foreground mb-12 leading-relaxed max-w-xl mx-auto"
                  >
                    Prends un instant. Ne cherche pas à formuler parfaitement. Laisse venir ce qui est là.
                  </motion.p>

                  <motion.form
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.6 }}
                    onSubmit={handleQuestionSubmit}
                    className="space-y-6"
                  >
                    <textarea
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      required
                      placeholder="Écris ce qui te traverse..."
                      className="w-full h-48 glass-strong rounded-2xl p-6 text-lg resize-none focus:outline-none focus:ring-2 focus:ring-accent transition-all duration-300 placeholder:text-muted-foreground/50 text-foreground"
                    />

                    <button
                      type="submit"
                      disabled={!question.trim()}
                      className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-none"
                    >
                      Lancer le tirage
                    </button>
                  </motion.form>
                </div>
              </motion.div>
            )}

            {phase === 'revealing' && (
              <motion.div
                key="revealing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
                className="min-h-screen flex flex-col items-center justify-center px-4 py-20"
              >
                <motion.p
                  key={loadingText}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="text-2xl md:text-3xl text-center text-muted-foreground mb-16"
                >
                  {loadingText}
                </motion.p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl w-full">
                  {drawnRunes.map((rune, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.2 }}
                      className="relative h-96"
                      style={{ perspective: '1000px' }}
                    >
                      <div
                        className="relative w-full h-full transition-all duration-700"
                        style={{
                          transformStyle: 'preserve-3d',
                          transform: revealedCards[index] ? 'rotateY(180deg)' : 'rotateY(0deg)'
                        }}
                      >
                        <div
                          className="absolute inset-0 glass-strong rounded-2xl flex items-center justify-center"
                          style={{ backfaceVisibility: 'hidden' }}
                        >
                          <div className="text-6xl opacity-20">ᚱᚢᚾᛖ</div>
                        </div>

                        <div
                          className={`absolute inset-0 glass-strong rounded-2xl flex flex-col items-center justify-center p-6 transition-all duration-700 ${
                            revealedCards[index] ? 'glow-primary' : ''
                          }`}
                          style={{
                            backfaceVisibility: 'hidden',
                            transform: 'rotateY(180deg)'
                          }}
                        >
                          <div className="text-8xl mb-4 text-accent">{rune.symbole}</div>
                          <div className="font-['Cinzel'] text-2xl font-semibold">{rune.nom}</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {phase === 'results' && (
              <motion.div
                key="results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
                className="min-h-screen py-20 px-4"
              >
                <div className="max-w-4xl mx-auto space-y-16">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6 }}
                    className="text-center"
                  >
                    <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
                      Il y a quelque chose de précis dans ce tirage. Pas forcément visible immédiatement, mais qui influence déjà ta situation.
                    </p>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.2 }}
                    className="glass rounded-2xl p-8"
                  >
                    <p className="text-sm text-muted-foreground mb-3">Par rapport à ce que tu traverses…</p>
                    <p className="text-xl leading-relaxed italic">{question}</p>
                  </motion.div>

                  <div className="space-y-12">
                    {drawnRunes.map((rune, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: 0.4 + index * 0.2 }}
                        className="glass rounded-2xl p-8"
                      >
                        <div className="mb-6">
                          <div className="text-sm font-medium text-accent mb-4 tracking-wide uppercase">
                            {POSITION_LABELS[index]}
                          </div>
                          <div className="flex items-center gap-4 mb-6">
                            <div className="text-6xl text-accent">{rune.symbole}</div>
                            <div className="font-['Cinzel'] text-3xl font-semibold">{rune.nom}</div>
                          </div>
                        </div>

                        <p className="text-muted-foreground leading-relaxed text-lg">
                          {rune.interpretation}
                        </p>
                      </motion.div>
                    ))}
                  </div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 1.2 }}
                    className="glass-strong rounded-2xl p-8"
                  >
                    <h3 className="font-['Cinzel'] text-2xl md:text-3xl font-semibold text-center mb-4">
                      Recevoir ce tirage
                    </h3>
                    <p className="text-center text-muted-foreground mb-8 leading-relaxed max-w-2xl mx-auto">
                      Recevoir ce tirage pour y revenir à tête reposée et observer ce qui évolue dans les prochains jours
                    </p>

                    {!emailSaved ? (
                      <form onSubmit={handleEmailSubmit} className="space-y-4 max-w-md mx-auto">
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                          placeholder="ton@email.com"
                          className="w-full glass rounded-xl px-6 py-4 text-lg focus:outline-none focus:ring-2 focus:ring-accent transition-all duration-300 placeholder:text-muted-foreground/50 text-foreground"
                        />
                        <button
                          type="submit"
                          disabled={!email.trim()}
                          className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Recevoir mon tirage
                        </button>
                      </form>
                    ) : (
                      <p className="text-center text-accent text-lg">Tirage enregistré</p>
                    )}
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 1.4 }}
                    className="glass rounded-2xl p-8 text-center"
                  >
                    <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8 max-w-2xl mx-auto">
                      Ce tirage met en lumière quelque chose de plus profond que ce que tu vois ici. Une lecture plus précise permet de comprendre ce qui se joue réellement dans ta situation.
                    </p>
                    <button className="glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98]">
                      Approfondir ce tirage
                    </button>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 1.6 }}
                    className="flex flex-col sm:flex-row gap-4 justify-center pt-8"
                  >
                    <button
                      onClick={handleNewDraw}
                      className="glass-strong px-8 py-4 rounded-xl text-lg font-medium hover:bg-muted/50 transition-all duration-300 active:scale-[0.98]"
                    >
                      Faire un nouveau tirage
                    </button>
                  </motion.div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
};

export default HomePage;

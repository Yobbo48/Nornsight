
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const LoadingPhase = ({ onLoadingComplete }) => {
  const [loadingText, setLoadingText] = useState('Connexion aux runes...');

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setLoadingText('Lecture en cours...');
    }, 1500);

    const timer2 = setTimeout(() => {
      onLoadingComplete();
    }, 3000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [onLoadingComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center px-4"
    >
      <motion.p
        key={loadingText}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0.4, 1, 0.4] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="text-2xl md:text-3xl text-center text-muted-foreground"
      >
        {loadingText}
      </motion.p>
    </motion.div>
  );
};

export default LoadingPhase;


import React, { useState } from 'react';
import { motion } from 'framer-motion';

const QuestionPhase = ({ onSubmit }) => {
  const [question, setQuestion] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (question.trim()) {
      onSubmit(question.trim());
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center px-4 py-20"
    >
      <div className="max-w-2xl w-full">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-['Cinzel'] text-4xl md:text-5xl font-bold text-center mb-6"
          style={{ letterSpacing: '-0.02em' }}
        >
          Quelle est ta question ou la situation que tu traverses ?
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg text-center text-muted-foreground mb-12 leading-relaxed max-w-xl mx-auto"
        >
          Prends un instant. Ne cherche pas à formuler parfaitement. Laisse venir ce qui est là.
        </motion.p>

        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          onSubmit={handleSubmit}
          className="space-y-6"
        >
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            required
            placeholder="Écris ce qui te traverse..."
            className="w-full h-48 glass-strong rounded-2xl p-6 text-lg resize-none focus:outline-none focus:ring-2 focus:ring-accent transition-all duration-300 placeholder:text-muted-foreground/50"
          />

          <button
            type="submit"
            disabled={!question.trim()}
            className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-none"
          >
            Lancer le tirage
          </button>
        </motion.form>
      </div>
    </motion.div>
  );
};

export default QuestionPhase;

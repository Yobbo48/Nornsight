
import React from 'react';
import { motion } from 'framer-motion';

const FinalPhase = ({ onReturnLater, onNewDraw }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center px-4 py-20"
    >
      <div className="max-w-2xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="space-y-6"
        >
          <button
            onClick={onReturnLater}
            className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium hover:bg-muted/50 transition-all duration-300 active:scale-[0.98]"
          >
            Revenir voir ce tirage plus tard
          </button>

          <button
            onClick={onNewDraw}
            className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98]"
          >
            Faire un nouveau tirage
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default FinalPhase;

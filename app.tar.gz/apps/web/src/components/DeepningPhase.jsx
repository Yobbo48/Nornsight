
import React from 'react';
import { motion } from 'framer-motion';

const DeepningPhase = ({ onContinue }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center px-4 py-20"
    >
      <div className="max-w-2xl w-full text-center">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-['Cinzel'] text-4xl md:text-5xl font-bold mb-6"
          style={{ letterSpacing: '-0.02em' }}
        >
          Ce tirage met en lumière une dynamique plus profonde
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg text-muted-foreground mb-12 leading-relaxed max-w-xl mx-auto"
        >
          Une lecture plus précise permet de comprendre ce qui se joue réellement dans ta situation.
        </motion.p>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          onClick={onContinue}
          className="glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98]"
        >
          Approfondir ce tirage
        </motion.button>
      </div>
    </motion.div>
  );
};

export default DeepningPhase;

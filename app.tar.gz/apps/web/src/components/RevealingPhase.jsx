
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const RevealingPhase = ({ runes, onRevealComplete }) => {
  const [revealedCards, setRevealedCards] = useState([false, false, false]);

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setRevealedCards([true, false, false]);
    }, 500);

    const timer2 = setTimeout(() => {
      setRevealedCards([true, true, false]);
    }, 2000);

    const timer3 = setTimeout(() => {
      setRevealedCards([true, true, true]);
    }, 3500);

    const timer4 = setTimeout(() => {
      onRevealComplete();
    }, 5000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onRevealComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center px-4 py-20"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl w-full">
        {runes.map((rune, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.2 }}
            className="relative h-96"
            style={{ perspective: '1000px' }}
          >
            <div
              className="relative w-full h-full transition-all duration-700"
              style={{
                transformStyle: 'preserve-3d',
                transform: revealedCards[index] ? 'rotateY(180deg)' : 'rotateY(0deg)'
              }}
            >
              <div
                className="absolute inset-0 glass-strong rounded-2xl flex items-center justify-center"
                style={{ backfaceVisibility: 'hidden' }}
              >
                <div className="text-6xl opacity-20">ᚱᚢᚾᛖ</div>
              </div>

              <div
                className={`absolute inset-0 glass-strong rounded-2xl flex flex-col items-center justify-center p-6 transition-all duration-700 ${
                  revealedCards[index] ? 'glow-primary' : ''
                }`}
                style={{
                  backfaceVisibility: 'hidden',
                  transform: 'rotateY(180deg)'
                }}
              >
                <div className="text-8xl mb-4 text-accent">{rune.symbole}</div>
                <div className="font-['Cinzel'] text-2xl font-semibold mb-4">{rune.nom}</div>
                <p className="text-sm text-center text-muted-foreground leading-relaxed">
                  {rune.interpretation}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default RevealingPhase;

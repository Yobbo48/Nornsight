
import React, { useState } from 'react';
import { motion } from 'framer-motion';

const EmailPhase = ({ runes, question, onEmailSubmitted }) => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email.trim()) {
      const tirage = {
        email: email.trim(),
        question,
        runes,
        date: Date.now(),
        status: 'saved'
      };

      try {
        const existingTirages = JSON.parse(localStorage.getItem('nornsight_tirages') || '[]');
        existingTirages.push(tirage);
        localStorage.setItem('nornsight_tirages', JSON.stringify(existingTirages));
        onEmailSubmitted();
      } catch (error) {
        console.error('Error saving to localStorage:', error);
        onEmailSubmitted();
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen flex items-center justify-center px-4 py-20"
    >
      <div className="max-w-2xl w-full">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-['Cinzel'] text-4xl md:text-5xl font-bold text-center mb-6"
          style={{ letterSpacing: '-0.02em' }}
        >
          Recevoir ton tirage
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg text-center text-muted-foreground mb-12 leading-relaxed max-w-xl mx-auto"
        >
          Tu peux recevoir ce tirage par email, pour y revenir à tête reposée et observer son évolution.
        </motion.p>

        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          onSubmit={handleSubmit}
          className="space-y-6"
        >
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder="ton@email.com"
            className="w-full glass-strong rounded-xl px-6 py-4 text-lg focus:outline-none focus:ring-2 focus:ring-accent transition-all duration-300 placeholder:text-muted-foreground/50"
          />

          <button
            type="submit"
            disabled={!email.trim()}
            className="w-full glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-none"
          >
            Recevoir mon tirage
          </button>
        </motion.form>
      </div>
    </motion.div>
  );
};

export default EmailPhase;

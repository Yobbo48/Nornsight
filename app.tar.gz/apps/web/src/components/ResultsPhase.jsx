
import React from 'react';
import { motion } from 'framer-motion';

const POSITION_LABELS = ['Dynamique actuelle', 'Point sensible', 'Mouvement possible'];

const ResultsPhase = ({ runes, question, onContinue }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen py-20 px-4"
    >
      <div className="max-w-4xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-lg text-center text-muted-foreground mb-8 leading-relaxed max-w-2xl mx-auto"
        >
          Ce tirage ne répond pas à tout. Mais il met en lumière ce qui est déjà en train de se jouer dans ta situation.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="glass rounded-2xl p-6 mb-12"
        >
          <p className="text-sm text-muted-foreground mb-2">Par rapport à ce que tu traverses :</p>
          <p className="text-lg leading-relaxed">{question}</p>
        </motion.div>

        <div className="space-y-12 mb-12">
          {runes.map((rune, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 + index * 0.2 }}
              className="glass rounded-2xl p-8"
            >
              <div className="mb-4">
                <div className="text-sm font-medium text-accent mb-3 tracking-wide uppercase">
                  {POSITION_LABELS[index]}
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-6xl text-accent">{rune.symbole}</div>
                  <div className="font-['Cinzel'] text-3xl font-semibold">{rune.nom}</div>
                </div>
              </div>

              <div className="mt-6">
                <p className="text-muted-foreground leading-relaxed text-lg">
                  {rune.interpretation}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.2 }}
          className="flex justify-center"
        >
          <button
            onClick={onContinue}
            className="glass-strong px-8 py-4 rounded-xl text-lg font-medium glow-accent hover:glow-accent-strong transition-all duration-300 active:scale-[0.98]"
          >
            Continuer
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default ResultsPhase;

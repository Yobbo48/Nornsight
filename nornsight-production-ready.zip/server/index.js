import { createServer } from 'node:http';
import { existsSync, createReadStream, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRuneReading } from '../apps/web/server/runeReadingService.js';
import { createFreeTirage, saveTirageEmail, unlockFullTirage } from '../apps/web/server/tirageService.js';
import { getDrawingRepository, getDrawingRepositoryMode } from '../apps/web/server/data/drawingRepository.js';
import { getMysqlDebugInfo } from '../apps/web/server/data/mysqlClient.js';
import { getRequestIp } from '../apps/web/server/utils/requestContext.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const DIST_DIR = path.resolve(ROOT_DIR, 'dist/apps/web');
const BLOCKED_PATH_PREFIXES = [
  '/.git',
  '/.env',
  '/server',
  '/apps',
  '/src',
  '/node_modules',
  '/package',
  '/pnpm-lock',
  '/package-lock',
  '/yarn.lock',
  '/HOSTINGER_DEPLOY',
  '/server/sql'
];
const BLOCKED_PATH_SEGMENTS = ['/.', '/..'];
const BLOCKED_EXTENSIONS = new Set(['.map', '.log', '.sql', '.env']);

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8'
};

function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function sendText(res, statusCode, message) {
  res.writeHead(statusCode, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Length': Buffer.byteLength(message)
  });
  res.end(message);
}

function applyCommonHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
}

function isPreviewAccess(url) {
  return url.searchParams.get('preview_paid') === '1';
}

function isBlockedStaticPath(pathname) {
  const lowered = pathname.toLowerCase();

  if (BLOCKED_PATH_SEGMENTS.some((segment) => lowered.includes(segment))) {
    return true;
  }

  if (BLOCKED_PATH_PREFIXES.some((prefix) => lowered === prefix || lowered.startsWith(`${prefix}/`))) {
    return true;
  }

  const extension = path.extname(lowered);
  if (BLOCKED_EXTENSIONS.has(extension)) {
    return true;
  }

  return false;
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';

    req.on('data', (chunk) => {
      raw += chunk;

      if (raw.length > 1_000_000) {
        reject(new Error('Payload too large.'));
        req.destroy();
      }
    });

    req.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (error) {
        reject(new Error('Invalid JSON body.'));
      }
    });

    req.on('error', reject);
  });
}

async function handleApi(req, res, pathname, url) {
  if (req.method === 'GET' && pathname === '/api/health') {
    const payload = {
      ok: true,
      service: 'nornsight',
      timestamp: new Date().toISOString()
    };

    if (isPreviewAccess(url)) {
      payload.storage = await getDrawingRepositoryMode();
      payload.mysql = getMysqlDebugInfo();
    }

    return sendJson(res, 200, payload);
  }

  if (req.method === 'GET' && pathname === '/api/admin/tirages') {
    if (!isPreviewAccess(url)) {
      return sendJson(res, 403, { error: 'Forbidden.' });
    }

    const repository = await getDrawingRepository();
    const limit = Number(url.searchParams.get('limit') || '20');
    const tirages = await repository.listRecentDrawings(limit);

    return sendJson(res, 200, { tirages });
  }

  if (req.method !== 'POST') {
    return sendJson(res, 405, { error: 'Method not allowed.' });
  }

  const requestIp = getRequestIp(req);
  const body = await readJsonBody(req);

  if (pathname === '/api/rune-reading') {
    const reading = await createRuneReading(body);
    return sendJson(res, 200, { reading });
  }

  if (pathname === '/api/tirages/free') {
    const result = await createFreeTirage({
      question: body.question,
      requestIp,
      locale: body.locale,
      theme: body.theme
    });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/tirages/save-email') {
    const result = await saveTirageEmail({
      tirageId: body.tirageId,
      email: body.email
    });
    return sendJson(res, 200, result);
  }

  if (pathname === '/api/tirages/unlock') {
    const result = await unlockFullTirage({
      ...body,
      requestIp
    });

    return sendJson(res, result.status === 'blocked' ? 429 : 200, result);
  }

  return sendJson(res, 404, { error: 'Not found.' });
}

function safeJoin(baseDir, pathname) {
  const filePath = path.join(baseDir, pathname);
  if (!filePath.startsWith(baseDir)) {
    return null;
  }
  return filePath;
}

function serveStatic(req, res, pathname) {
  if (!existsSync(DIST_DIR)) {
    return sendText(
      res,
      503,
      'Le build frontend est introuvable. Lancez "npm run build" avant de démarrer le serveur.'
    );
  }

  if (isBlockedStaticPath(pathname)) {
    return sendJson(res, 404, { error: 'Not found.' });
  }

  const cleanPath = pathname === '/' ? '/index.html' : pathname;
  const requestedFile = safeJoin(DIST_DIR, cleanPath);

  if (requestedFile && existsSync(requestedFile)) {
    const extension = path.extname(requestedFile).toLowerCase();
    const contentType = MIME_TYPES[extension] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': extension === '.html' ? 'no-cache' : 'public, max-age=604800, immutable'
    });

    createReadStream(requestedFile).pipe(res);
    return;
  }

  const indexPath = path.join(DIST_DIR, 'index.html');
  if (!existsSync(indexPath)) {
    return sendText(res, 404, 'index.html introuvable.');
  }

  res.writeHead(200, {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-cache'
  });

  res.end(readFileSync(indexPath));
}

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';

const server = createServer(async (req, res) => {
  applyCommonHeaders(res);

  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const pathname = decodeURIComponent(url.pathname);

    if (pathname.startsWith('/api/')) {
      await handleApi(req, res, pathname, url);
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(res, 405, { error: 'Method not allowed.' });
      return;
    }

    serveStatic(req, res, pathname);
  } catch (error) {
    console.error('Production server error:', error);
    sendJson(res, 500, { error: 'Internal server error.' });
  }
});

server.listen(port, host, () => {
  console.log(`Nornsight server running at http://${host}:${port}`);
});

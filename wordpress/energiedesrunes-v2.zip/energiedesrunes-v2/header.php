<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#faf9f7">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header" id="site-header" role="banner">
  <div class="wrap">
    <nav class="nav" role="navigation" aria-label="Navigation principale">

      <!-- Logo -->
      <a href="<?php echo esc_url(home_url('/')); ?>" class="nav__logo" aria-label="Accueil — L'Énergie des Runes">
        <?php if ( has_custom_logo() ) :
            the_custom_logo();
        else : ?>
          <span class="nav__logo-text">
            L'Énergie des Runes
            <span class="nav__logo-sub">Guidances · Soins · Formations</span>
          </span>
        <?php endif; ?>
      </a>

      <!-- Menu principal -->
      <ul class="nav__menu" id="nav-menu" role="menubar">
        <li role="none"><a href="<?php echo esc_url(home_url('/')); ?>" role="menuitem">Accueil</a></li>
        <li role="none"><a href="<?php echo esc_url(home_url('/a-propos')); ?>" role="menuitem">À propos</a></li>
        <li role="none"><a href="<?php echo esc_url(home_url('/services')); ?>" role="menuitem">Services</a></li>
        <li role="none"><a href="<?php echo esc_url(home_url('/formations')); ?>" role="menuitem">Formations</a></li>
        <li role="none"><a href="<?php echo esc_url(home_url('/le-livre')); ?>" role="menuitem">Le Livre</a></li>
        <li role="none"><a href="<?php echo esc_url(home_url('/blog')); ?>" role="menuitem">Blog</a></li>
        <li role="none">
          <a href="<?php echo esc_url(edr_opt('edr_nornsight_url','https://nornsight.com')); ?>"
             target="_blank" rel="noopener noreferrer"
             class="nav__nornsight"
             role="menuitem">
            Nornsight ↗
          </a>
        </li>
      </ul>

      <!-- CTA -->
      <div class="nav__cta">
        <a href="<?php echo esc_url(home_url('/reservation')); ?>" class="btn btn--primary btn--sm">
          Réserver une séance
        </a>
      </div>

      <!-- Burger mobile -->
      <button class="nav__burger" id="nav-burger" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="nav-drawer">
        <span></span><span></span><span></span>
      </button>

    </nav>
  </div>

  <!-- Mobile drawer -->
  <div class="nav__drawer" id="nav-drawer" role="dialog" aria-label="Menu mobile" aria-hidden="true">
    <a href="<?php echo esc_url(home_url('/')); ?>">Accueil</a>
    <a href="<?php echo esc_url(home_url('/a-propos')); ?>">À propos</a>
    <a href="<?php echo esc_url(home_url('/services')); ?>">Services</a>
    <a href="<?php echo esc_url(home_url('/formations')); ?>">Formations</a>
    <a href="<?php echo esc_url(home_url('/le-livre')); ?>">Le Livre</a>
    <a href="<?php echo esc_url(home_url('/blog')); ?>">Blog</a>
    <a href="<?php echo esc_url(edr_opt('edr_nornsight_url','https://nornsight.com')); ?>" target="_blank" rel="noopener">Nornsight ↗</a>
    <a href="<?php echo esc_url(home_url('/reservation')); ?>" class="btn btn--primary" style="text-align:center;margin-top:0.5rem;">
      Réserver une séance
    </a>
  </div>
</header>

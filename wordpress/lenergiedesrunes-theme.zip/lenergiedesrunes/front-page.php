<?php
if (! defined('ABSPATH')) {
	exit;
}

get_header();

$guidances = lenergiedesrunes_get_page_by_path('guidances-runiques');
$soins     = lenergiedesrunes_get_page_by_path('soins-energetiques-en-ligne');
$ateliers  = lenergiedesrunes_get_page_by_path('ateliers-runes-en-ligne');
$apropos   = lenergiedesrunes_get_page_by_path('a-propos');
$booking   = lenergiedesrunes_theme_value('booking_url');
?>

<section class="hero">
	<div class="container hero__grid">
		<div>
			<p class="eyebrow"><?php esc_html_e('Activite 100% en ligne', 'lenergiedesrunes'); ?></p>
			<h1><?php esc_html_e('Guidances et soins energetiques en ligne par les runes', 'lenergiedesrunes'); ?></h1>
			<p><?php esc_html_e("Des seances a distance pour retrouver clarte, apaisement et elan dans les passages de doute, de transition ou de blocage.", 'lenergiedesrunes'); ?></p>
			<div class="hero__actions">
				<?php if ($booking) : ?>
					<a class="button" href="<?php echo esc_url($booking); ?>"><?php esc_html_e('Reserver une seance', 'lenergiedesrunes'); ?></a>
				<?php endif; ?>
				<?php if ($guidances) : ?>
					<a class="button button--secondary" href="<?php echo esc_url(get_permalink($guidances)); ?>"><?php esc_html_e('Decouvrir les guidances', 'lenergiedesrunes'); ?></a>
				<?php endif; ?>
			</div>
		</div>
		<aside class="hero__card">
			<p class="eyebrow"><?php esc_html_e('Pour qui', 'lenergiedesrunes'); ?></p>
			<ul class="list-clean">
				<li><?php esc_html_e('Pour les personnes en recherche de clarte et de recentrage', 'lenergiedesrunes'); ?></li>
				<li><?php esc_html_e("Pour traverser un moment de doute, d'epuisement ou de transition", 'lenergiedesrunes'); ?></li>
				<li><?php esc_html_e('Pour recevoir un accompagnement sensible, structure et accessible a distance', 'lenergiedesrunes'); ?></li>
			</ul>
		</aside>
	</div>
</section>

<section class="section">
	<div class="container">
		<h2 class="section__title"><?php esc_html_e('Trois portes d entree', 'lenergiedesrunes'); ?></h2>
		<p class="section__intro"><?php esc_html_e("Le site doit conduire rapidement vers l'offre adaptee, sans noyer la visite dans trop de pages ou trop de promesses en meme temps.", 'lenergiedesrunes'); ?></p>
		<div class="services-grid">
			<?php foreach (array($guidances, $soins, $ateliers) as $page) : ?>
				<?php if (! $page) { continue; } ?>
				<article class="service-card">
					<h3><?php echo esc_html(get_the_title($page)); ?></h3>
					<p><?php echo esc_html(wp_trim_words(wp_strip_all_tags($page->post_content), 28)); ?></p>
					<a href="<?php echo esc_url(get_permalink($page)); ?>"><?php esc_html_e('Voir la page', 'lenergiedesrunes'); ?></a>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section">
	<div class="container split">
		<div class="page-panel">
			<p class="eyebrow"><?php esc_html_e('Seances a distance', 'lenergiedesrunes'); ?></p>
			<h2 class="section__title"><?php esc_html_e('Comment se passe une seance en ligne ?', 'lenergiedesrunes'); ?></h2>
			<ul>
				<li><?php esc_html_e('Prise de contact et cadrage du besoin', 'lenergiedesrunes'); ?></li>
				<li><?php esc_html_e('Seance a distance via visio, telephone ou format defini ensemble', 'lenergiedesrunes'); ?></li>
				<li><?php esc_html_e("Restitution claire, simple et ancree", 'lenergiedesrunes'); ?></li>
				<li><?php esc_html_e("Orientation vers l'offre la plus adaptee", 'lenergiedesrunes'); ?></li>
			</ul>
		</div>
		<div class="page-panel">
			<p class="eyebrow"><?php esc_html_e('A propos', 'lenergiedesrunes'); ?></p>
			<h2 class="section__title"><?php echo $apropos ? esc_html(get_the_title($apropos)) : esc_html__('Une approche claire et sensible', 'lenergiedesrunes'); ?></h2>
			<p><?php echo $apropos ? esc_html(wp_trim_words(wp_strip_all_tags($apropos->post_content), 48)) : esc_html__("Une pratique qui relie runes, intuition et accompagnement energetique, avec une volonte constante de rendre l'experience lisible, profonde et utile.", 'lenergiedesrunes'); ?></p>
			<?php if ($apropos) : ?>
				<a href="<?php echo esc_url(get_permalink($apropos)); ?>"><?php esc_html_e("Lire l'histoire", 'lenergiedesrunes'); ?></a>
			<?php endif; ?>
		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<h2 class="section__title"><?php esc_html_e('Articles recents', 'lenergiedesrunes'); ?></h2>
		<div class="posts-grid">
			<?php
			$recent_posts = new WP_Query(
				array(
					'post_type'      => 'post',
					'posts_per_page' => 4,
				)
			);

			if ($recent_posts->have_posts()) :
				while ($recent_posts->have_posts()) :
					$recent_posts->the_post();
					?>
					<article class="article-card">
						<p class="eyebrow"><?php echo esc_html(get_the_date()); ?></p>
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<p><?php echo esc_html(get_the_excerpt()); ?></p>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				?>
				<article class="article-card">
					<h3><?php esc_html_e('Le blog alimentera ton SEO', 'lenergiedesrunes'); ?></h3>
					<p><?php esc_html_e('Ajoute ici des articles evergreen sur les runes, les guidances et les soins energetiques en ligne.', 'lenergiedesrunes'); ?></p>
				</article>
				<?php
			endif;
			?>
		</div>
	</div>
</section>

<?php get_footer(); ?>

document.addEventListener("DOMContentLoaded", () => {
  const header = document.querySelector("header.wp-block-template-part");

  const syncHeader = () => {
    if (!header) return;
    header.classList.toggle("is-scrolled", window.scrollY > 16);
  };

  syncHeader();
  document.addEventListener("scroll", syncHeader, { passive: true });

  document.querySelectorAll("[data-edr-reveal]").forEach((element) => {
    element.style.opacity = "1";
    element.style.transform = "none";
  });
});

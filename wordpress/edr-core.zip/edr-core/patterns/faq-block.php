<?php
/**
 * Title: EDR / Bloc FAQ
 * Slug: edr-core/faq-block
 * Categories: text
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-faq-block","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-faq-block">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">FAQ</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2} -->
<h2>Questions frequentes</h2>
<!-- /wp:heading -->
<!-- wp:list -->
<ul><li>Comment se passe une seance a distance ?</li><li>Faut-il deja connaitre les runes ?</li><li>Comment choisir entre tirage et soin ?</li></ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<?php
/**
 * Title: EDR / Bloc Calendly
 * Slug: edr-core/calendly-block
 * Categories: call-to-action
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-calendly-block","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-calendly-block">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">Reservation</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3>Reserver une seance a distance</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Toutes les seances se font a distance, par telephone, visioconference ou email, avec la meme qualite d'accompagnement, depuis chez vous, sans deplacement.</p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<div class="edr-calendly-embed">Integrer ici l'embed Calendly global.</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

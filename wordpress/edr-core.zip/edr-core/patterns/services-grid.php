<?php
/**
 * Title: EDR / Grille Services
 * Slug: edr-core/services-grid
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-section">
<!-- wp:group {"className":"edr-section__heading","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-section__heading">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">Services</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2>Des accompagnements clairs, a distance, selon votre situation</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:query {"queryId":1,"query":{"perPage":6,"postType":"edr_service","order":"asc","orderBy":"menu_order","inherit":false},"className":"edr-grid edr-grid--services"} -->
<div class="wp-block-query edr-grid edr-grid--services"><!-- wp:post-template -->
<!-- wp:group {"className":"edr-card-service","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-card-service">
<!-- wp:paragraph {"className":"edr-card-rune"} -->
<p class="edr-card-rune">ᚱ</p>
<!-- /wp:paragraph -->
<!-- wp:post-title {"isLink":true,"level":3} /-->
<!-- wp:post-excerpt {"moreText":"Voir le service"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
</div>
<!-- /wp:group -->

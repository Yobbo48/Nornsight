<?php
/**
 * Title: EDR / CTA Simple
 * Slug: edr-core/cta-simple
 * Categories: call-to-action
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-newsletter-block","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-newsletter-block">
<!-- wp:heading {"level":3} -->
<h3>Pret(e) a faire le point ?</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Choisissez le format d'accompagnement qui vous correspond et reservez votre seance a distance.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/reserver/">Reserver une seance</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<?php
/**
 * Title: EDR / Bandeau Livre
 * Slug: edr-core/book-banner
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-book-banner is-dark","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-book-banner is-dark">
<!-- wp:heading {"level":2} -->
<h2>Le Petit Guide des Runes</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Une ressource complementaire aux seances et aux ateliers, disponible en librairie et en ligne.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

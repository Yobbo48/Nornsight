<?php
/**
 * Title: EDR / Bloc Newsletter
 * Slug: edr-core/newsletter-block
 * Categories: call-to-action
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-newsletter-block","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-newsletter-block">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">Newsletter</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3>Recevez des contenus utiles autour des runes, des tirages et des temps de transition</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Sans spam. Desinscription en un clic.</p>
<!-- /wp:paragraph -->
<form data-edr-newsletter-form>
  <p><input type="email" placeholder="Votre adresse email" required></p>
  <p><button type="submit">S'inscrire</button></p>
  <p data-edr-newsletter-message></p>
</form>
</div>
<!-- /wp:group -->

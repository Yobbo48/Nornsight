<?php
/**
 * Title: EDR / Hero Accueil
 * Slug: edr-core/hero-home
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-hero","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-hero">
<!-- wp:paragraph -->
<p>Activite 100% en ligne</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1} -->
<h1>Guidance runique &amp; soins energetiques pour avancer avec clarte</h1>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Separation, transition professionnelle, blocages inexpliques, perte de direction : des seances a distance pour vous aider a faire le point, sans deplacement, depuis toute la France.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<?php
/**
 * Title: EDR / Comment ca se passe
 * Slug: edr-core/process-steps
 * Categories: text
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-process-steps","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-process-steps">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">Comment ca se passe</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2} -->
<h2>Un cadre simple, lisible et accessible a distance</h2>
<!-- /wp:heading -->
<!-- wp:list {"ordered":true} -->
<ol><li>Prise de contact et cadrage du besoin</li><li>Choix du format adapte : telephone, visio ou email</li><li>Seance et restitution claire</li><li>Integration et suite si necessaire</li></ol>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

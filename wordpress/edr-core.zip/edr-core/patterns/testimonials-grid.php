<?php
/**
 * Title: EDR / Grille Temoignages
 * Slug: edr-core/testimonials-grid
 * Categories: text
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-section">
<!-- wp:group {"className":"edr-section__heading","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-section__heading">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">Temoignages</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2>Ce que les clients disent des seances</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:columns {"className":"edr-grid edr-grid--testimonials"} -->
<div class="wp-block-columns edr-grid edr-grid--testimonials">
<!-- wp:column --><div class="wp-block-column"><!-- wp:group {"className":"edr-testimonial"} --><div class="wp-block-group edr-testimonial"><!-- wp:paragraph --><p>"Des coups de boosts qui m'ont bien aide a avancer dans ma vie."</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><strong>Florie L.</strong></p><!-- /wp:paragraph --></div><!-- /wp:group --></div><!-- /wp:column -->
<!-- wp:column --><div class="wp-block-column"><!-- wp:group {"className":"edr-testimonial"} --><div class="wp-block-group edr-testimonial"><!-- wp:paragraph --><p>"Kevin est un professionnel bienveillant et tres a l'ecoute."</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><strong>Amandine G.</strong></p><!-- /wp:paragraph --></div><!-- /wp:group --></div><!-- /wp:column -->
<!-- wp:column --><div class="wp-block-column"><!-- wp:group {"className":"edr-testimonial"} --><div class="wp-block-group edr-testimonial"><!-- wp:paragraph --><p>"Un eclairage clair, direct et humain, sans jugement."</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><strong>Avis client</strong></p><!-- /wp:paragraph --></div><!-- /wp:group --></div><!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->

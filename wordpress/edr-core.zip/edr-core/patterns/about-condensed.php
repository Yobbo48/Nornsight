<?php
/**
 * Title: EDR / A propos condense
 * Slug: edr-core/about-condensed
 * Categories: text
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-about-condensed","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-about-condensed">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">A propos</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2} -->
<h2>Une approche directe, bienveillante, sans jugement</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Issu du commerce et de l'informatique, Kevin Legros s'est tourne vers les runes en 2015 comme vers un axe de clarte, de lecture et de transmission. Son approche relie pratique, recul et accessibilite, sans exiger que vous croyiez en quoi que ce soit.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/a-propos/">Lire la page complete</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

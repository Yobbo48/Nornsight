<?php
/**
 * Title: EDR / Grille Formations
 * Slug: edr-core/training-grid
 * Categories: featured
 * Inserter: true
 */
?>
<!-- wp:group {"className":"edr-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-section">
<!-- wp:group {"className":"edr-section__heading","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-section__heading">
<!-- wp:paragraph {"className":"edr-eyebrow"} -->
<p class="edr-eyebrow">Formations</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2>Des formats de transmission pour apprendre et pratiquer</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:query {"queryId":2,"query":{"perPage":6,"postType":"edr_training","order":"asc","orderBy":"menu_order","inherit":false},"className":"edr-grid edr-grid--trainings"} -->
<div class="wp-block-query edr-grid edr-grid--trainings"><!-- wp:post-template -->
<!-- wp:group {"className":"edr-card-training","layout":{"type":"constrained"}} -->
<div class="wp-block-group edr-card-training">
<!-- wp:paragraph {"className":"edr-card-rune"} -->
<p class="edr-card-rune">ᚠ</p>
<!-- /wp:paragraph -->
<!-- wp:post-title {"isLink":true,"level":3} /-->
<!-- wp:post-excerpt {"moreText":"Voir la formation"} /-->
</div>
<!-- /wp:group -->
<!-- /wp:post-template --></div>
<!-- /wp:query -->
</div>
<!-- /wp:group -->

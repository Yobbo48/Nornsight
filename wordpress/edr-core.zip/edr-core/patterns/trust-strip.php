<?php
/**
 * Title: EDR / Bandeau Confiance
 * Slug: edr-core/trust-strip
 * Categories: text
 * Inserter: true
 */
?>
<!-- wp:list -->
<ul><li>21 avis 5 etoiles Google</li><li>8+ ans de pratique</li><li>100% en ligne partout en France</li><li>Livre publie en librairie nationale</li></ul>
<!-- /wp:list -->

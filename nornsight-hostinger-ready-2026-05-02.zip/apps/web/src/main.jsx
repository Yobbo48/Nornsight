import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import AppErrorBoundary from '@/components/AppErrorBoundary.jsx';
import '@/index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
	<AppErrorBoundary>
		<App />
	</AppErrorBoundary>
);
